"""Functions for joining batch prediction and ground truth dataset."""

import copy
import enum
import json
from typing import Iterable, Tuple, List, Optional, Any

from absl import logging
import apache_beam as beam
from vertexevaluation.lib import column_spec
from vertexevaluation.lib import column_spec_proto_lib
from vertexevaluation.lib import evaluation_column_specs as ecs
from vertexevaluation.proto import configuration_pb2

ColumnSpec = column_spec.ColumnSpec
EvaluationColumnSpecs = ecs.EvaluationColumnSpecs

STRING_TO_BYTES_ENCODING = 'ascii'
# The type of prediction being selected to compute eval metrics.
AUTOML_VIDEO_CLASSIFICATION_PREDICTION_TYPE = 'segment-classification'
AUTOML_VIDEO_BATCH_PREDICTION_OUTPUT_PUBLIC_DOC = 'https://cloud.google.com/vertex-ai/docs/predictions/batch-predictions#example_batch_prediction_results'
JOIN_KEY_DELIMITER = 'VERTEX_JOIN_KEY_DELIMITER'


class DataSourceType(enum.Enum):
  """Data source that is being processed.

  Values:
    BATCH_PREDICTION: Files containing Batch Prediction output.
    GROUND_TRUTH: Files containing ground truth.
  """
  BATCH_PREDICTION = 1
  GROUND_TRUTH = 2


class FindKeyForJsonLData(beam.DoFn):
  """Yields a pair of <join_key, prediction_instance>."""

  def __init__(self, key_prefix: str, key_columns: Optional[List[str]] = None):
    """Construct a transformation.

    Args:
      key_prefix: The prefix of the key columns.
      key_columns: The list of keys' column specs in each input record, used to
        format join key.
    """
    self._key_prefix = key_prefix
    self._key_columns = key_columns

  def process(self, input_data: str) -> Iterable[Tuple[str, str]]:
    """Emits a pair of key and value for one prediction instance.

    Args:
      input_data: A JSON serialized dict of features, labels, and predictions.

    Yields:
      A pair of key (prediction intance key) and value (prediction instance).
    """
    try:
      array_prediction_join_key, updated_data = _format_key_and_dict_json_for_array_prediction(
          input_data, self._key_prefix, self._key_columns)
      if array_prediction_join_key:
        yield (array_prediction_join_key, updated_data)
      else:
        key = _format_instance_key(input_data, self._key_prefix,
                                   self._key_columns)
        yield (key, input_data)
    except ValueError as e:
      yield beam.pvalue.TaggedOutput(
          'errors',
          ('Not able to find key for jsonl data, error: [%s]', str(e)))


class MergePredictionWithGroundTruth(beam.DoFn):
  """Yields a merged prediction + ground truth instance."""

  def __init__(self,
               key_prefix_in_prediction_dataset: str,
               key_columns: Optional[List[str]] = None):
    """Construct a transformation.

    Args:
      key_prefix_in_prediction_dataset: The prefix in batch prediction dataset.
      key_columns: The column names which values can be used to format join key.
    """
    self._key_prefix_in_prediction_dataset = key_prefix_in_prediction_dataset
    self._key_columns = key_columns

  def process(self, key_values: Tuple[str, Any]) -> Iterable[bytes]:
    """Emits a merged prediction instance and ground truth.

    Args:
      key_values: A list of join key and instance (batch prediction or ground
        truth) values.

    Yields:
      An instance containing the merged batch prediction and ground truth data.
    """
    try:
      merged_instance_str = self.process_input_value(key_values)
      if merged_instance_str:
        yield merged_instance_str
    except ValueError as e:
      yield beam.pvalue.TaggedOutput(
          'errors',
          ('Not able to merge prediction with ground truth, error: [%s]',
           str(e)))

  def process_input_value(self, key_values: Tuple[str, Any]) -> Optional[bytes]:
    """Returns a merged prediction instance and ground truth.

    Args:
      key_values: A list of join key and instance (batch prediction or ground
        truth) values.

    Returns:
      An instance containing the merged batch prediction and ground truth data.
    """
    join_key, joined_tuple = key_values
    if not joined_tuple:
      return
    if len(list(joined_tuple)) != 2:
      raise ValueError(
          'Expecting a tuple of batch prediction instance and ground truth '
          f'instance for one join key {join_key}, seeing {len(list(joined_tuple))}'
      )
    instance_number = None
    for instance_list in joined_tuple:
      if not instance_list:
        return b''
      if instance_number and len(instance_list) != instance_number:
        raise ValueError(
            'Expecting same number of batch prediction instance and ground truth'
            f' instance for one join key {join_key}, seeing'
            f'{len(instance_list)} and {instance_number}'
            f'in tuple {joined_tuple}')
      instance_number = len(instance_list)
    if instance_number != 1:
      logging.warning(
          'Expecting one prediction instance, seeing %s for join key %s',
          instance_number, join_key)

    key_prefix_column_spec = column_spec_proto_lib.build_column_spec(
        self._key_prefix_in_prediction_dataset
    ) if self._key_prefix_in_prediction_dataset else None
    if key_prefix_column_spec:
      prediction_dataset_index = None
      ground_truth_dataset_index = None
      for index, value in enumerate(joined_tuple):
        instance = value[0]
        if not isinstance(instance, str):
          raise ValueError(f'instance not str, it is {instance}')
        if _check_instance_match_prefix_and_keys(instance, self._key_columns,
                                                 key_prefix_column_spec):
          prediction_dataset_index = index
        elif _check_instance_match_prefix_and_keys(instance, self._key_columns,
                                                   None):
          ground_truth_dataset_index = index
      if prediction_dataset_index is None or ground_truth_dataset_index is None:
        return b''
      merged_instance = json.loads(
          _find_segment_for_one_key_column(
              key_prefix_column_spec,
              list(joined_tuple)[prediction_dataset_index][0]))
      merged_instance.update(
          json.loads(list(joined_tuple)[ground_truth_dataset_index][0]))
      merged_instance_str = _replace_sub_instance(
          key_prefix_column_spec, json.dumps(merged_instance),
          list(joined_tuple)[prediction_dataset_index][0])
    else:
      merged_instance = {}
      for index, value in enumerate(joined_tuple):
        instance = value[0]
        if not isinstance(instance, str):
          raise ValueError(f'instance not str, it is {instance}')
        if _check_instance_match_prefix_and_keys(instance, self._key_columns,
                                                 None):
          merged_instance.update(json.loads(list(joined_tuple)[index][0]))
      if not merged_instance:
        return b''
      merged_instance_str = json.dumps(merged_instance)
    # Handle the special case for AutoML Video Classification: if the prediction
    # is an array, extract only AUTOML_VIDEO_CLASSIFICATION_PREDICTION_TYPE
    # type.
    # TODO(qij): use component type to tell.
    merged_instance_str = _refactor_automl_vcn_predictions(merged_instance_str)
    return bytes(merged_instance_str, STRING_TO_BYTES_ENCODING)


def _format_segment_float(segment: str) -> str:
  """Formats input number to 5 decimal points if it is a number."""
  # Float check.
  try:
    return f'{float(segment):.5f}'
  except ValueError:
    return segment


def _format_key_and_dict_json_for_array_prediction(
    input_data: str, key_prefix: str,
    key_columns: List[Any]) -> Tuple[str, str]:
  """Extracts join key and convert value to dictionary for array predictions.

  Args:
    input_data: The instance encoded as bytes.
    key_prefix: The prefix of key fields, this can only be non-empty for batch
      prediction dataset.
    key_columns: The column names which values can be used to format join key.

  Returns:
    A formatted join key for the input_data.
  """
  try:
    instance_json = json.loads(input_data)
  except json.decoder.JSONDecodeError as decoder_error:
    raise ValueError(f'Cannot decode line {input_data}') from decoder_error

  # If the key_prefix is provided, the instance should be a dictionary and
  # contains key_prefix. Otherwise it is not the array prediction.
  if key_prefix:
    if (not isinstance(instance_json, dict)) or (key_prefix
                                                 not in instance_json):
      return ('', input_data)
    instance_json = instance_json[key_prefix]
  # If the prediction from the instance is not array, skip this instance.
  if not isinstance(instance_json, list):
    return ('', input_data)

  if len(instance_json) != len(key_columns):
    raise ValueError(
        'Expecting same length of feature names in array type' +
        f' of predictions, seeing {len(instance_json)} length of {input_data}' +
        f', {len(key_columns)} length of features {key_columns}')
  # Format the join key.
  segments = []
  # Format the value as a dictionary.
  prediction_dict = {}
  for segment_idx in range(len(instance_json)):
    prediction_dict[key_columns[segment_idx]] = instance_json[segment_idx]
    segment = str(instance_json[segment_idx]).strip('\"')
    segment = _format_segment_float(segment)
    if not segment:
      segment = (f'VERTEX_EMPTY_{key_columns[segment_idx].upper()}')
    segments.append(segment)
  key = JOIN_KEY_DELIMITER.join(segments)
  # Fit in the dictionary prediction into the prefix.
  if key_prefix:
    updated_input_data = _replace_sub_instance(
        column_spec_proto_lib.build_column_spec(key_prefix),
        json.dumps(prediction_dict), input_data)
  return (key, updated_input_data)


def _format_instance_key(input_data: str, key_prefix: str,
                         key_columns: List[Any]) -> str:
  """Extracts the join key from an instance with given key prefix and columns.

  Args:
    input_data: The instance encoded as bytes.
    key_prefix: The prefix of key fields, this can only be non-empty for batch
      prediction dataset.
    key_columns: The column names which values can be used to format join key.

  Returns:
    A formatted join key for the input_data.
  """
  segments = []
  for key in key_columns:
    key = key.decode('utf-8') if isinstance(key, bytes) else key
    key_column_spec = column_spec_proto_lib.build_column_spec(key)
    if key_prefix:
      key_column_spec = column_spec_proto_lib.build_column_spec(key_prefix)
      if key_column_spec:
        key_column_spec.sub_column_spec.CopyFrom(
            column_spec_proto_lib.build_column_spec(key))
    segment = _find_segment_for_one_key_column(key_column_spec,
                                               input_data).strip('\"')
    segment = _format_segment_float(segment)
    if not segment:
      segment = (f'VERTEX_EMPTY_{key.upper()}')
    segments.append(segment)
  return JOIN_KEY_DELIMITER.join(segments)


def _extract_key_for_array_prediction(input_data: bytes, key_prefix: str,
                                      key_columns: List[Any]) -> str:
  """Extracts the join key if the instance contains array type of prediction.

  Args:
    input_data: The instance encoded as bytes.
    key_prefix: The prefix of key fields, this can only be non-empty for batch
      prediction dataset.
    key_columns: The column names which values can be used to format join key.

  Returns:
    A formatted join key for the input_data if it is array type of prediction.
  """
  try:
    instance_json = json.loads(input_data)
  except json.decoder.JSONDecodeError as decoder_error:
    raise ValueError(f'Cannot decode line {input_data}') from decoder_error

  # If the key_prefix is provided, the instance should be a dictionary and
  # contain key_prefix. Otherwise it is not the array prediction.
  if key_prefix:
    if (not isinstance(instance_json, dict)) or (key_prefix
                                                 not in instance_json):
      return ''
    instance_json = instance_json[key_prefix]
  # If the prediction from the instance is not array, skip this instance.
  if not isinstance(instance_json, list):
    return ''
  if len(instance_json) != len(key_columns):
    raise ValueError(
        'Expecting same length of feature names in array type' +
        f' of predictions, seeing {len(instance_json)} length of {input_data}' +
        f', {len(key_columns)} length of features {key_columns}')
  return JOIN_KEY_DELIMITER.join([str(segment) for segment in instance_json])


def _refactor_automl_vcn_predictions(instance_data: str) -> str:
  """Refactor predictions by extracting "segment-classification" type.

  Args:
    instance_data: The instance containing predictions to be refactored.

  Returns:
    An updated instance_data with only
    AUTOML_VIDEO_CLASSIFICATION_PREDICTION_TYPE predictions.
  """
  instance_json = json.loads(instance_data)
  if ((not isinstance(instance_json, dict)) or
      ('prediction' not in instance_json) or
      (not isinstance(instance_json['prediction'], list))):
    return instance_data
  predictions = instance_json['prediction']
  # Skip if the items in prediction list is not dictionary,
  # because AutoML video classification always have a list of dictionries.
  if (not predictions) or (not isinstance(predictions[0], dict)):
    return instance_data
  classes = []
  confidences = []
  for prediction in predictions:
    # Validate the prediction instance.
    if (('type' not in prediction) or ('displayName' not in prediction) or
        ('confidence' not in prediction)):
      raise ValueError(
          'Expecting AutoML Video Classification Batch Prediction results to '
          'contain "type", "displayName", and "confidence" field, '
          f'see {AUTOML_VIDEO_BATCH_PREDICTION_OUTPUT_PUBLIC_DOC} for samples.')
    if prediction['type'] == AUTOML_VIDEO_CLASSIFICATION_PREDICTION_TYPE:
      classes.append(prediction['displayName'])
      confidences.append(prediction['confidence'])
  if not classes or not confidences:
    raise ValueError(
        f'No {AUTOML_VIDEO_CLASSIFICATION_PREDICTION_TYPE} type from '
        f'predictions {predictions}')
  instance_json['prediction'] = {
      'displayName': classes,
      'confidence': confidences
  }
  return json.dumps(instance_json)


def _replace_sub_instance(prefix_column_spec: configuration_pb2.ColumnSpec,
                          sub_component_data: str,
                          whole_instance_data: str) -> str:
  """Replace prefix_column_spec in whole_instance_data with sub_component_data.

  Args:
    prefix_column_spec: the prefix indicating which section of
      whole_instance_data should be replaced.
    sub_component_data: The sub component that should be used to replace.
    whole_instance_data: The whole instance containing prefix column.

  Returns:
    An updated whole_instance_data with prefix_column_spec replaced by
    sub_component_data.
  """
  whole_instance_json = json.loads(whole_instance_data)
  sub_component_json = json.loads(sub_component_data)
  if not isinstance(whole_instance_json, dict) or not isinstance(
      sub_component_json, dict):
    raise ValueError(
        f'Not able to merge {sub_component_data} into {whole_instance_json} '
        f'(expected dict type, actually {type(whole_instance_json)}) with '
        f'prefix {column_spec_proto_lib.column_spec_to_string(prefix_column_spec)}'
    )
  current_column_spec = copy.deepcopy(prefix_column_spec)
  parent_instance_json = None
  current_instance_json = whole_instance_json
  while current_column_spec.name:
    if current_column_spec.name not in current_instance_json:
      break
    parent_instance_json = current_instance_json
    current_instance_json = current_instance_json[current_column_spec.name]
    if not current_column_spec.HasField('sub_column_spec'):
      parent_instance_json[current_column_spec.name] = sub_component_json
      break
    current_column_spec = copy.deepcopy(current_column_spec.sub_column_spec)
  return json.dumps(parent_instance_json)


def _find_segment_for_one_key_column(
    key_column_spec: configuration_pb2.ColumnSpec, instance_data: Any) -> str:
  """Returns the value of key_column_spec in instance.

  Args:
    key_column_spec: The column spec indicating the field to look up value in
      the instance.
    instance_data: The instance containing key column.

  Returns:
    The value of the key column in the instance.
  """
  try:
    instance_json = json.loads(instance_data)
  except json.decoder.JSONDecodeError as decoder_error:
    raise ValueError(f'Cannot decode line {instance_data}') from decoder_error
  if not isinstance(instance_json, dict):
    if not key_column_spec or not key_column_spec.name:
      return json.dumps(instance_json)
    return ''
  if key_column_spec and key_column_spec.name in instance_json:
    sub_instance_json_str = json.dumps(instance_json[key_column_spec.name])
    return _find_segment_for_one_key_column(
        key_column_spec.sub_column_spec, sub_instance_json_str
    ) if key_column_spec.HasField('sub_column_spec') else sub_instance_json_str
  return ''


def _check_field_exist_in_instance(
    key_column_spec: configuration_pb2.ColumnSpec, instance_data: str) -> bool:
  """Check whether the given field exists in the instance.

  Args:
    key_column_spec: The column spec of the field to check existence.
    instance_data: The instance containing key_column_spec.

  Returns:
    A boolean indicating whether the field exists.
  """
  try:
    instance_json = json.loads(instance_data)
  except json.decoder.JSONDecodeError as decoder_error:
    raise ValueError(f'Cannot decode line {instance_data}') from decoder_error
  if not isinstance(instance_json, dict):
    if not key_column_spec.name:
      return True
    return False
  if key_column_spec.name not in instance_json:
    return False
  if not key_column_spec.HasField('sub_column_spec'):
    return True
  return _check_field_exist_in_instance(
      key_column_spec.sub_column_spec,
      json.dumps(instance_json[key_column_spec.name]))


def _check_instance_match_prefix_and_keys(
    instance_data: str,
    key_columns: List[str],
    prefix_column_spec: Optional[configuration_pb2.ColumnSpec] = None) -> bool:
  """Check whether the specific prefix and key fields exists in the instance.

  Args:
    instance_data: The instance containing key_column_spec.
    key_columns: The column names which values can be used to format join key.
    prefix_column_spec: The prefix of key fields, this can only be non-empty for
      batch prediction dataset.

  Returns:
    A boolean indicating whether the prefix and key fields exist in the
    instance.
  """
  sub_instance_data = _find_segment_for_one_key_column(
      prefix_column_spec,
      instance_data) if prefix_column_spec else instance_data
  if not sub_instance_data:
    return False

  for key_column in key_columns:
    if not _check_field_exist_in_instance(
        column_spec_proto_lib.build_column_spec(key_column), sub_instance_data):
      return False
  return True
