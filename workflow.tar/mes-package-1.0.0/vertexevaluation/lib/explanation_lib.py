"""Beam operator for aggregating explanation metrics."""

import dataclasses
import functools
import json
from typing import Dict, Any, Sequence

import apache_beam as beam


def aggregate_feature_attribution(merged_dataset: beam.PCollection,
                                  output_path: str):
  """Aggregates explanation steps to a beam pipelines merged dataset.

  Args:
    merged_dataset: Something.
    output_path: Path to output explanations to.

  Returns:
    Nothing.

  """
  _ = (
      merged_dataset
      | "FilterInvalidInstance" >> beam.Filter(is_valid_json)
      | "FromJSON" >> beam.Map(json.loads)
      | "CalculateFeatureImportance" >> beam.CombineGlobally(
          ComputeModelFeatureImportanceFn())
      | "ToJSON" >> beam.Map(json.dumps)
      | "WriteToFile" >> beam.io.WriteToText(
          file_path_prefix=output_path,
          shard_name_template="",
          file_name_suffix=""))


def is_valid_json(instance: str) -> bool:
  """Checks whether the instance is a valid JSON object.

  Args:
    instance: One line of text from the input file.

  Returns:
    A boolean indicating whether the instance is valid json or not.
  """
  try:
    json.loads(instance)
    return True
  except json.decoder.JSONDecodeError:
    return False


@dataclasses.dataclass
class WeightedAverage:
  """Contains feature importance and weight."""
  average: Dict[Any, Any] = dataclasses.field(default_factory=dict)
  weight: int = 0


class ComputeModelFeatureImportanceFn(beam.CombineFn):
  """Beam function for averaging feature importance across the dataset."""

  def create_accumulator(self) -> WeightedAverage:
    return WeightedAverage()

  def add_input(self, accumulator: WeightedAverage, input_: Any):
    try:
      feature_attribution = input_["explanation"]["attributions"][0][
          "featureAttributions"]
    except (KeyError, IndexError):
      return accumulator

    # TODO(b/240607070): Account for weight column
    return self.merge_accumulators(
        [accumulator,
         WeightedAverage(average=feature_attribution, weight=1)])

  def merge_accumulators(
      self, accumulators: Sequence[WeightedAverage]) -> WeightedAverage:
    if not accumulators:
      return WeightedAverage(weight=0, average={})
    total_count = sum([acc.weight for acc in accumulators])
    return WeightedAverage(
        weight=total_count,
        average=functools.reduce(
            aggregate_dict_value,
            [
                average_dict_value(acc.average, total_count / acc.weight)
                for acc in accumulators
                if acc.weight
            ], {}
        ))

  def extract_output(self, accumulator: WeightedAverage) -> Dict[str, Any]:
    return {
        "explanation": {
            "attributions": [{
                "featureAttributions": accumulator.average
            }]
        }
    }


def aggregate_dict_value(dict_value, aggregated_dict_value):
  """Aggregate values for two dicts.

  Args:
    dict_value: A dict value.
    aggregated_dict_value: A dict value to be aggregated to.

  Returns:
    The aggregated dict value.
  """
  if not dict_value:
    return aggregated_dict_value
  if not aggregated_dict_value:
    return dict_value
  for key, value in dict_value.items():
    if isinstance(value, dict):
      if key in aggregated_dict_value:
        aggregates_to = aggregated_dict_value[key]
        if not isinstance(aggregates_to, dict):
          raise TypeError("Mismatched type between %s and %s for key: %s" %
                          (value, aggregates_to, key))
        value = aggregate_dict_value(value, aggregates_to)
      aggregated_dict_value[key] = value
    elif isinstance(value, list):
      if key in aggregated_dict_value:
        aggregates_to = aggregated_dict_value[key]
        if not isinstance(aggregates_to, list):
          if isinstance(aggregates_to, (float, int)):
            aggregates_to = [aggregates_to]
          else:
            raise TypeError("Mismatched type between %s and %s for key: %s" %
                            (value, aggregates_to, key))

        value = aggregate_list_value(value, aggregates_to)
      aggregated_dict_value[key] = aggregate_list_value(value, [])
    elif isinstance(value, (float, int)):
      if key in aggregated_dict_value:
        aggregates_to = aggregated_dict_value[key]
        if not isinstance(aggregates_to, (float, int)):
          if isinstance(aggregates_to, list):
            # b/201319772 only happens for list features, so we should always
            # aggregate to list value when it happens.
            value = aggregate_list_value([value], aggregates_to)
          else:
            raise TypeError("Mismatched type between %s and %s for key: %s" %
                            (value, aggregates_to, key))
        else:
          value = aggregate_scalar_value(value, aggregates_to)
      aggregated_dict_value[key] = value
    else:
      raise TypeError("Unexpected type %s:%s" % (key, value))
  return aggregated_dict_value


def aggregate_list_value(list_value, aggregated_list_value):
  """Aggregates values for two lists.

  Args:
    list_value: A list value.
    aggregated_list_value: A list value to be aggregated to.

  Returns:
    The aggregated list value.
  """
  if not list_value:
    raise ValueError("Unexpected list value %s" % list_value)
  if isinstance(list_value[0], dict):
    if aggregated_list_value:
      return [aggregate_dict_value(list_value[0], aggregated_list_value[0])]
    else:
      return [list_value[0]]
  elif isinstance(list_value[0], list):
    if aggregated_list_value:
      return [aggregate_list_value(list_value[0], aggregated_list_value[0])]
    else:
      return [list_value[0]]
  elif isinstance(list_value[0], (float, int)):
    if aggregated_list_value:
      return [aggregate_scalar_value(list_value[0], aggregated_list_value[0])]
    else:
      return [list_value[0]]
  else:
    raise ValueError("Unexpected list value %s" % list_value)


def aggregate_scalar_value(scalar_value, aggregated_scalar_value):
  """Aggregates two scalar values.

  Args:
    scalar_value: A scalar value.
    aggregated_scalar_value: A scalar value to be aggregated to.

  Returns:
    The aggregated scalar value.
  """
  return abs(scalar_value) + abs(aggregated_scalar_value)


def average_list_value(list_value, counts):
  """Returns average list values by counts.

  Args:
    list_value: A list value.
    counts: Counts to divide.

  Returns:
    The averaged list value.
  """
  if not list_value:
    return []
  if isinstance(list_value[0], dict):
    return [average_dict_value(list_value[0], counts)]
  elif isinstance(list_value[0], list):
    return [average_list_value(list_value[0], counts)]
  elif isinstance(list_value[0], (float, int)):
    return [list_value[0] / float(counts)]


def average_dict_value(dict_value, counts):
  """Returns average dict values by counts.

  Args:
    dict_value: A dict value.
    counts: Counts to divide.

  Returns:
    The averaged dict value.
  """
  for key, value in dict_value.items():
    if isinstance(value, dict):
      dict_value[key] = average_dict_value(value, counts)
    elif isinstance(value, list):
      dict_value[key] = average_list_value(value, counts)
    elif isinstance(value, (float, int)):
      dict_value[key] = value / float(counts)
  return dict_value


def is_valid_explanation_response(entry):
  """Checks if the provided entry is a valid explanation response dict."""
  return (entry is not None and isinstance(entry, dict) and
          ("explanation" in entry))
