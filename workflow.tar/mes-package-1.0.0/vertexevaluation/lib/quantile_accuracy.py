"""Provides custom metrics for Tensorflow Model Analysis."""

from typing import Dict, List, Optional, Text

import apache_beam as beam
import numpy as np
import tensorflow_model_analysis as tfma
from vertexevaluation.lib import constants
from vertexevaluation.proto import model_evaluation_pb2


class QuantileAccuracy(tfma.metrics.Metric):
  """Quantile accuracy."""

  def __init__(self,
               quantiles: List[float],
               name: Text = constants.Metric.QUANTILE_ACCURACY):
    """Initializes quantile accuracy.

    Args:
      quantiles: Quantile list.
      name: Metric name.
    """
    super(QuantileAccuracy, self).__init__(
        tfma.metrics.merge_per_key_computations(_quantile_accuracy),
        quantiles=quantiles,
        name=name)


def _quantile_accuracy(
    quantiles: List[float],
    name: Text = constants.Metric.QUANTILE_ACCURACY,
    model_name: Text = '',
    output_name: Text = '',
    sub_key: Optional[tfma.metrics.SubKey] = None,
) -> tfma.metrics.MetricComputations:
  """Returns metric computations for quantile accuracy."""
  # The key of the source metrics should be different from the target key.
  metrics_key = tfma.metrics.MetricKey(
      name=f'{name}.metrics',
      model_name=model_name,
      output_name=output_name,
      sub_key=sub_key)
  key = tfma.metrics.MetricKey(
      name=name,
      model_name=model_name,
      output_name=output_name,
      sub_key=sub_key)

  def result(
      metrics: Dict[tfma.metrics.MetricKey, QuantileStatisticsAccumulator]
  ) -> Dict[tfma.metrics.MetricKey, bytes]:
    statistics = metrics[metrics_key]
    fe_proto = model_evaluation_pb2.ForecastingEvaluationMetrics()
    for i, quantile in enumerate(quantiles):
      qt_value = model_evaluation_pb2.ForecastingEvaluationMetrics.QuantileMetricsEntry(
      )
      qt_value.quantile = quantile
      qt_value.scaled_pinball_loss = statistics[1, i] / statistics[1, -1]
      qt_value.observed_quantile = statistics[0, i] / statistics[0, -1]
      fe_proto.quantile_metrics.append(qt_value)
    return {key: fe_proto.SerializeToString()}

  computations = [
      tfma.metrics.MetricComputation(
          keys=[metrics_key],
          preprocessor=None,
          combiner=_QuantileStatisticsCombiner(metrics_key, quantiles,
                                               model_name)),
      tfma.metrics.DerivedMetricComputation(keys=[key], result=result)
  ]
  return computations


QuantileStatisticsAccumulator = np.ndarray


class _QuantileStatisticsCombiner(beam.CombineFn):
  """Computes quantile statistics."""

  def __init__(self, key: tfma.metrics.MetricKey, quantiles: List[float],
               model_name: Text):
    self._key = key
    self._quantiles = np.array(quantiles)
    self._model_name = model_name

  def create_accumulator(self) -> QuantileStatisticsAccumulator:
    return np.zeros(shape=(2, len(self._quantiles) + 1), dtype=np.float)

  def add_input(
      self, accumulator: QuantileStatisticsAccumulator,
      element: tfma.metrics.StandardMetricInputs
  ) -> QuantileStatisticsAccumulator:
    if self._model_name:
      label = element.label[self._model_name]
      pred = element.prediction[self._model_name]
      weight = element.example_weight[
          self._model_name] if element.example_weight else 1
    else:
      label = element.label
      pred = element.prediction
      weight = element.example_weight if element.example_weight else 1
    accumulator[0, -1] += 1
    accumulator[1, -1] += weight
    # Computes the weighted counts of target value that is less than the
    # predicted value of the quantile, for each quantile.
    # The math formula is: (target <= predictions[i])
    accumulator[0, :-1] += (label <= pred)
    # Computes the scaled pinball loss for each quantile.
    # The math formula is:
    # (
    #  max(quantiles[i] * (target - predictions[i]), 0) +
    #  max((quantiles[i] - 1) * (target - predictions[i]), 0)
    # ) * weight
    loss = label - pred
    func = np.vectorize(lambda t: max(t, 0.0), otypes=[float])
    accumulator[1, :-1] += (func(self._quantiles * loss) + func(
        (self._quantiles - 1) * loss)) * weight
    return accumulator

  def merge_accumulators(
      self, accumulators: List[QuantileStatisticsAccumulator]
  ) -> QuantileStatisticsAccumulator:
    total_accum = self.create_accumulator()
    for accum in accumulators:
      total_accum += accum
    return total_accum

  def extract_output(
      self, accumulator: QuantileStatisticsAccumulator
  ) -> Dict[tfma.metrics.MetricKey, QuantileStatisticsAccumulator]:
    return {self._key: accumulator}
