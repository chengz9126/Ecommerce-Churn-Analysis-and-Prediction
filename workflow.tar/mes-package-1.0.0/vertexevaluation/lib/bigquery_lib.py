"""Process BigQuery table library access."""

import re
from typing import Tuple, Sequence, Mapping, Any, Union

from google.api_core import exceptions
from google.cloud import bigquery
from vertexevaluation.error import error

_BQ_PROJECT_ID = 'project_id'
_BQ_DATASET_ID = 'dataset_id'
_BQ_TABLE_ID = 'table_id'

BQ_PERMISSION_ERR_PATTERN = 'Permission.*bigquery.*denied'
BQ_PERMISSION_ERR_MSG = ('Permission denied. BigQuery Data Editor '
                         '(roles/bigquery.dataEditor) IAM role (or higher) is '
                         'required.')
UserError = error.UserError


def parse_bigquery_uri(bq_uri: str) -> Tuple[str, str, str]:
  """Parses the BigQuery URI into project-id, dataset-id, and table-id."""

  matched = re.match(
      r'^^(bq|bigquery)://(?P<' + _BQ_PROJECT_ID +
      '>([a-z0-9.-]+:)?[a-z][a-z0-9-]{4,28}[a-z0-9])[:\\.](?P<' +
      _BQ_DATASET_ID + '>[a-zA-Z0-9_]+)[:\\.](?P<' + _BQ_TABLE_ID +
      '>[a-zA-Z0-9_]+)$', bq_uri)
  if not matched:
    raise ValueError(
        'Invalid BigQuery URI: {}, expecting bq://<project_id>.<dataset_id>.<table_id>'
        .format(bq_uri))
  matched_dict = matched.groupdict()

  if len(
      matched_dict
  ) != 3 or _BQ_PROJECT_ID not in matched_dict or _BQ_DATASET_ID not in matched_dict or _BQ_TABLE_ID not in matched_dict:
    raise ValueError(
        'Invalid BigQuery URI: {}, expecting bq://<project_id>.<dataset_id>.<table_id>'
        .format(bq_uri))

  return matched_dict[_BQ_PROJECT_ID], matched_dict[
      _BQ_DATASET_ID], matched_dict[_BQ_TABLE_ID]


def query_for_result(project_id: str,
                     query_str: str) -> bigquery.table.RowIterator:
  """Sends the BigQuery query and wait for results."""
  try:
    with bigquery.Client(project=project_id) as client:
      query_job = client.query(query_str)
      return query_job.result()
  except (exceptions.GoogleAPICallError, TypeError) as e:
    bq_permission_err = re.search(BQ_PERMISSION_ERR_PATTERN, str(e))
    if bq_permission_err:
      raise UserError(BQ_PERMISSION_ERR_MSG) from e
    raise RuntimeError('Internal Error: Pipeline Failed. %s' % e) from e


def get_table_schema(
    client: bigquery.Client, table_id: str
) -> Sequence[Union[bigquery.schema.SchemaField, Mapping[str, Any]]]:
  """Gets the BigQuery table schema.

  Args:
    client: BigQuery Client.
    table_id: a string of BigQuery Table ID. E.g.
      'your-project.your_dataset.your_table'

  Returns:
    A list of BigQuery table schema.
  Raises:
    UsageError: error occuring when BigQuery source does not exist.
  """
  try:
    table = client.get_table(table_id)
    return table.schema
  except exceptions.NotFound as e:
    raise UserError('BigQuery table %s not found.' % table_id) from e


def check_if_table_exists_and_get_schema(
    bq_uri: str
) -> Sequence[Union[bigquery.schema.SchemaField, Mapping[str, Any]]]:
  """Checks if BigQuery table exists from URI, returns table schema if exists.

  Args:
    bq_uri: a string of BigQuery Table URI. E.g.
      "bq://your-project.your_dataset.your_table"

  Returns:
    A list of BigQuery table schema.
  """
  bq_project, bq_dataset, bq_table = parse_bigquery_uri(bq_uri)
  table_id = f'{bq_project}.{bq_dataset}.{bq_table}'

  with bigquery.Client(project=bq_project) as client:
    table_schema_list = get_table_schema(client, table_id)

  return table_schema_list
