"""Custom metric for mean squared percentage error."""

import tensorflow as tf


class MeanSquaredPercentageError(tf.python.keras.metrics.MeanMetricWrapper):
  """Computes the mean squared percentage error between `y_true` and `y_pred`."""

  def __init__(self, name="mean_squared_percentage_error", dtype=None):
    super().__init__(mean_squared_percentage_error, name, dtype=dtype)


def mean_squared_percentage_error(y_true, y_pred):
  """Computes the mean squared percentage error between `y_true` and `y_pred`.

  `loss = square(mean((y_true - y_pred) / y_true, axis=-1)`

  Args:
    y_true: Ground truth values. shape = `[batch_size, d0, .. dN]`.
    y_pred: The predicted values. shape = `[batch_size, d0, .. dN]`.

  Returns:
    Mean squared error values. shape = `[batch_size, d0, ..
    dN-1]`.
  """
  y_pred = tf.convert_to_tensor(y_pred)
  y_true = tf.cast(y_true, y_pred.dtype)
  diff = tf.square(
      (y_true - y_pred) /
      tf.keras.backend.maximum(tf.abs(y_true), tf.keras.backend.epsilon()))

  return tf.keras.backend.mean(diff, axis=-1)
