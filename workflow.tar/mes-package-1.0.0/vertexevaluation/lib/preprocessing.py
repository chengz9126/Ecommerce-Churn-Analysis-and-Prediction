"""Backend of the Preprocessing Components of the Model Evaluation Service."""

import csv
import io
import json
import os
from typing import List
import uuid

from absl import logging
import apache_beam as beam
from google.cloud import bigquery
import pandas as pd
import tensorflow.compat.v1 as tf
from vertexevaluation.error import error
from vertexevaluation.lib import artifact_util
from vertexevaluation.lib import bigquery_lib
from vertexevaluation.lib import column_spec
from vertexevaluation.lib import column_spec_proto_lib
from vertexevaluation.lib import config
from vertexevaluation.lib import constants
from vertexevaluation.lib import pipeline_arg_parser
from vertexevaluation.lib import pipeline_options
from vertexevaluation.proto import configuration_pb2
from vertexevaluation.proto import preprocessing_pb2

from google.protobuf import json_format

_USAGE = """
  main.py --task=<evaluation|data_splitter|data_sampler> --config=<serialized_json>
"""

_ERROR_MSG_TARGET_FIELD_NAME = ('Target field "{}" not found in input data.')

ColumnSpec = column_spec.ColumnSpec
UserError = error.UserError


def _get_config_from_args(argv) -> preprocessing_pb2.PreprocessingRunConfig:
  """Builds a preprocessing component run config.

  Args:
    argv: Arguments received from command line.

  Returns:
    PreprocessingRunConfig object for the component configuration.
  """
  pipeline_opts = pipeline_options.ModelEvaluationServiceOptions(argv)
  if pipeline_opts.config:
    # Config provided in json format
    return json_format.ParseDict(pipeline_opts.config,
                                 preprocessing_pb2.PreprocessingRunConfig())
  else:
    return pipeline_arg_parser.build_preprocessing_config(argv)


def _read_headers(csv_file: str) -> str:
  """Parses CSV header into a string.

  Args:
    csv_file: A string representing input CSV file source.

  Returns:
    A string of comma-delimited CSV file headers.
  """
  with tf.io.gfile.GFile(csv_file, 'r') as f:
    header_line = f.readline().strip().replace('"', '')
  return header_line


def _dict_to_csv(element,
                 column_order,
                 missing_val='',
                 discard_extras=True,
                 dialect=csv.excel):
  """Additional properties for delimiters, escape chars, etc via an instance of csv.Dialect.
  """

  buf = io.StringIO()

  writer = csv.DictWriter(
      buf,
      fieldnames=column_order,
      restval=missing_val,
      extrasaction=('ignore' if discard_extras else 'raise'),
      dialect=dialect)
  writer.writerow(element)

  return buf.getvalue().rstrip(dialect.lineterminator)


class _DictToCSVFn(beam.DoFn):
  """Converts a Dictionary to a CSV-formatted String.

    Attributes:
      column_order: A tuple or list specifying the name of fields to be
        formatted as csv, in order
      missing_val: The value to be written when a named field from
        `column_order` is not found in the input element
      discard_extras: (bool) Behavior when additional fields are found in the
        dictionary input element
      dialect: Delimiters, escape-characters, etc can be controlled by providing
        an instance of csv.Dialect
  """

  def __init__(self,
               column_order,
               missing_val='',
               discard_extras=True,
               dialect=csv.excel):
    self._column_order = column_order
    self._missing_val = missing_val
    self._discard_extras = discard_extras
    self._dialect = dialect

  def process(self, element, *args, **kwargs):
    result = _dict_to_csv(
        element,
        column_order=self._column_order,
        missing_val=self._missing_val,
        discard_extras=self._discard_extras,
        dialect=self._dialect)

    yield result


def write_to_gcs_output(task_config, dataflow_output_path):
  """Writes to output GCS File."""
  component_output_path = task_config.output.gcs_sink.uri
  logging.warning('Preprocessed Dataset GCS_URI: %s', dataflow_output_path)
  logging.warning('Component Output GCS OUTPUT_PATH: %s', component_output_path)

  with tf.io.gfile.GFile(component_output_path, 'w') as f:
    f.write(json.dumps([dataflow_output_path]))

  # Create empty file for bigquery output uri
  empty_output_path = task_config.output.bigquery_output_directory
  with tf.io.gfile.GFile(empty_output_path, 'w') as f:
    f.write('')


def write_to_bigquery_output(task_config, bigquery_output_uri):
  """Writes to output GCS File."""
  component_output_path = task_config.output.bigquery_output_directory
  logging.warning('Preprocessed Dataset BIGQUERY_TABLE_URI: %s',
                  bigquery_output_uri)
  logging.warning('Component Output GCS OUTPUT_PATH: %s', component_output_path)

  with tf.io.gfile.GFile(component_output_path, 'w') as f:
    f.write(bigquery_output_uri)

  # Create empty file for gcs output path
  empty_output_path = task_config.output.gcs_sink.uri
  with tf.io.gfile.GFile(empty_output_path, 'w') as f:
    f.write(json.dumps([]))


class SplitInstances(beam.DoFn):

  def process(self, instances):
    for item in instances:
      yield item


class SplitDataset(beam.DoFn):
  """Remove target field from parsed dataset in dictionary format."""

  def __init__(self, target_field_name: str):
    self._target_field = target_field_name
    self.is_nested_target_field = False

    if column_spec_proto_lib.COLUMN_SPEC_PROTO_DELIMITER in target_field_name:
      self.is_nested_target_field = True
      specs = target_field_name.split(
          column_spec_proto_lib.COLUMN_SPEC_PROTO_DELIMITER)
      self._column_spec = ColumnSpec(specs)

  def process(self, item):
    if self.is_nested_target_field:
      self._column_spec.pop_value_from_dict(item)
      yield item
    else:
      try:
        item.pop(self._target_field)
        yield item
      except KeyError as e:
        raise UserError(
            _ERROR_MSG_TARGET_FIELD_NAME.format(self._target_field)) from e


def extend_sampler_pipeline(
    sampler_config: preprocessing_pb2.PreprocessingRunConfig,
    input_files: List[str], input_format: str,
    output_path: str) -> beam.Pipeline:
  """Extends a beam pipeline to downsample dataset given the configuartion.

  Args:
    sampler_config: A Data Sampler configuration from preprocessing_pb2.
    input_files: A list of input dataset file GCS uri(s)
    input_format: A string of input format specification
    output_path: A GCS location string where to store sampled dataset.

  Returns:
    The beam pipeline.
  """

  pipeline_config = config.get_pipeline_options_from_service_config(
      task_run_name=sampler_config.name,
      task_execution_spec=sampler_config.execution)
  pipeline = beam.Pipeline(options=pipeline_config)

  if input_format == 'CSV':
    csv_headers = _read_headers(str(input_files[0]))
    _ = (
        pipeline
        | 'InputFileList' >> beam.Create(input_files)
        | 'ReadText' >> beam.io.textio.ReadAllFromText(skip_header_lines=1)
        | 'Sample N elements' >> beam.combiners.Sample.FixedSizeGlobally(
            sampler_config.sample_size)
        | 'Format Output' >> beam.ParDo(SplitInstances())
        | 'WriteToFile' >> beam.io.WriteToText(
            file_path_prefix=output_path,
            shard_name_template='',
            file_name_suffix='',
            header=csv_headers))

  elif input_format == 'JSONL':
    _ = (
        pipeline
        | 'InputFileList' >> beam.Create(input_files)
        | 'ReadText' >> beam.io.textio.ReadAllFromText()
        | 'Sample N elements' >> beam.combiners.Sample.FixedSizeGlobally(
            sampler_config.sample_size)
        | 'Format Output' >> beam.ParDo(SplitInstances())
        | 'WriteToFile' >> beam.io.WriteToText(
            file_path_prefix=output_path,
            shard_name_template='',
            file_name_suffix=''))
  return pipeline


def bigquery_sampler(client: bigquery.Client,
                     sampler_config: preprocessing_pb2.PreprocessingRunConfig,
                     input_table_uri: str,
                     output_table_uri: str) -> bigquery.QueryJob:
  """Extends a beam pipeline to downsample dataset given the configuartion.

  Args:
    client: BigQuery client
    sampler_config: A Data Sampler configuration from preprocessing_pb2.
    input_table_uri: input dataset BigQuery table uri
    output_table_uri: A string of the BigQuery table to store the output
      dataset.

  Returns:
    The BigQuery query job.
  """
  input_project, input_dataset, input_table = bigquery_lib.parse_bigquery_uri(
      input_table_uri)
  output_project, output_dataset, output_table = bigquery_lib.parse_bigquery_uri(
      output_table_uri)

  input_table_name = f'{input_project}.{input_dataset}.{input_table}'
  output_table_name = f'{output_project}.{output_dataset}.{output_table}'

  bigquery_query = f"""CREATE OR REPLACE TABLE
  {output_table_name} AS (
  SELECT
    *
  FROM
    {input_table_name}
  ORDER BY
    rand()
  LIMIT
    {sampler_config.sample_size});"""

  query_job = client.query(bigquery_query)
  return query_job


def extend_splitter_pipeline(
    splitter_config: preprocessing_pb2.PreprocessingRunConfig,
    input_files: List[str], input_format: str,
    output_path: str) -> beam.Pipeline:
  """Extends a beam pipeline to split dataset given the configuration.

  Args:
      splitter_config: A Data Splitter configuration from preprocessing_pb2.
      input_files: A list of input dataset file GCS uri(s)
      input_format: A string of input format specification
      output_path: A string of the GCS location to store the output dataset.

  Returns:
    The beam pipeline.
  """
  pipeline_config = config.get_pipeline_options_from_service_config(
      task_run_name=splitter_config.name,
      task_execution_spec=splitter_config.execution)
  pipeline = beam.Pipeline(options=pipeline_config)
  target_field_name = splitter_config.target_field_name

  if input_format == 'CSV':
    csv_headers = _read_headers(str(input_files[0])).split(',')
    if not csv_headers:
      raise UserError('CSV headers not found in the provided file.')

    try:
      csv_headers.remove(target_field_name)
    except ValueError as e:
      raise UserError(
          _ERROR_MSG_TARGET_FIELD_NAME.format(target_field_name)) from e

    _ = (
        pipeline
        | 'InputFileList' >> beam.Create(input_files)
        # Convert to a Pandas DataFrame, then into a PCollection of dictionaries
        | 'ReadCSV' >> beam.Map(pd.read_csv)
        | 'ToDict' >> beam.FlatMap(lambda df: df.to_dict('records'))
        | 'RemoveTargetField' >> beam.ParDo(SplitDataset(target_field_name))
        | 'ConvertToCSV' >> beam.ParDo(_DictToCSVFn(csv_headers))
        | 'WriteToFile' >> beam.io.WriteToText(
            file_path_prefix=output_path,
            shard_name_template='',
            file_name_suffix='',
            header=','.join(csv_headers)))

  elif input_format == 'JSONL':
    _ = (
        pipeline
        | 'InputFileList' >> beam.Create(input_files)
        | 'ReadFiles' >> beam.io.textio.ReadAllFromText()
        | 'LoadJSONDict' >> beam.Map(json.loads)
        | 'RemoveTargetField' >> beam.ParDo(SplitDataset(target_field_name))
        | 'DumpJSONDict' >> beam.Map(json.dumps)
        | 'WriteToFile' >> beam.io.WriteToText(
            file_path_prefix=output_path,
            shard_name_template='',
            file_name_suffix=''))
  return pipeline


def validate_bigquery_target_field(client: bigquery.Client, table_id: str,
                                   target_field_name: str):
  """Validate if the target field exists in BigQuery table or not.

  Args:
      client: BigQuery client
      table_id: BigQuery table ID in format <project_id>.<dataset_id>.<table_id>
      target_field_name: target field column name
  """
  table_schema = bigquery_lib.get_table_schema(client, table_id)
  for column in table_schema:
    if isinstance(column, bigquery.schema.SchemaField):
      if column.name == target_field_name:
        return
    else:  # column is Mapping[str, Any].
      if column.get('name') == target_field_name:
        return
  else:
    raise UserError(_ERROR_MSG_TARGET_FIELD_NAME.format(target_field_name))


def bigquery_splitter(client: bigquery.Client,
                      splitter_config: preprocessing_pb2.PreprocessingRunConfig,
                      input_table_uri: str,
                      output_table_uri: str) -> bigquery.QueryJob:
  """Extends a beam pipeline to split bigquery dataset given the configuration.

  Args:
      client: BigQuery client
      splitter_config: A Data Splitter configuration from preprocessing_pb2.
      input_table_uri: input dataset BigQuery table uri
      output_table_uri: A string of the BigQuery table to store the output
        dataset.

  Returns:
    The BigQuery query job.
  """
  target_field_name = splitter_config.target_field_name

  input_project, input_dataset, input_table = bigquery_lib.parse_bigquery_uri(
      input_table_uri)
  output_project, output_dataset, output_table = bigquery_lib.parse_bigquery_uri(
      output_table_uri)

  input_table_name = f'{input_project}.{input_dataset}.{input_table}'
  output_table_name = f'{output_project}.{output_dataset}.{output_table}'

  validate_bigquery_target_field(client, input_table_name, target_field_name)

  bigquery_query = f"""CREATE OR REPLACE TABLE
  {output_table_name} COPY {input_table_name};
  ALTER TABLE {output_table_name} DROP COLUMN IF EXISTS {target_field_name}"""

  query_job = client.query(bigquery_query)
  return query_job


def data_sampler_run(argv):
  """Runs pipeline to write randomly sampled dataset to GCS location."""
  sampler_config = _get_config_from_args(argv)
  kfp_pipeline_opts = pipeline_options.KfpOptions(argv)
  data_source = sampler_config.data_source

  if data_source.HasField('gcs_source') or data_source.single_source.HasField(
      'gcs_source'):
    input_files = list(data_source.gcs_source.files) if data_source.HasField(
        'gcs_source') else list(data_source.single_source.gcs_source.files)
    if sampler_config.output.gcs_sink.HasField('path'):
      dataflow_output_path = sampler_config.output.gcs_sink.path
    else:
      pipeline_opts = pipeline_options.ModelEvaluationServiceOptions(argv)
      dataset_root = os.path.join(pipeline_opts.root_dir,
                                  constants.Pipeline.PREPROCESSING_DATASET)
      os.makedirs(dataset_root, exist_ok=True)
      dataflow_output_path = os.path.join(dataset_root,
                                          constants.Pipeline.SAMPLER_KEY)

    # supported_format: 'CSV', 'JSONL'
    data_format = data_source.gcs_source.format if data_source.HasField(
        'gcs_source') else data_source.single_source.gcs_source.format
    if data_format == configuration_pb2.DataSource.GcsSource.CSV or all(
        ['.csv' in file for file in input_files]):
      input_format = 'CSV'
    elif data_format == configuration_pb2.DataSource.GcsSource.JSONL:
      input_format = 'JSONL'
    else:
      raise UserError('Unsupported data_source.gcs_source.'
                      f'format: {data_format}')

    result = extend_sampler_pipeline(
        sampler_config=sampler_config,
        input_files=input_files,
        input_format=input_format,
        output_path=dataflow_output_path,
    ).run()

    # Early cancellation
    artifact_util.run_with_cancellation_propagation(sampler_config.execution,
                                                    result, kfp_pipeline_opts)

    # Wrtie to output
    if kfp_pipeline_opts.executor_input:
      write_to_gcs_output(sampler_config, dataflow_output_path)

  else:
    input_table_uri = data_source.single_source.bigquery_source.uri

    if sampler_config.output.bigquery_table_uri:
      bigquery_output_table_uri = sampler_config.output.bigquery_table_uri
    else:
      bigquery_output_table_uri = f'{input_table_uri}_{constants.Pipeline.SAMPLER_KEY}_{uuid.uuid4().hex}'

    project_id, _, _ = bigquery_lib.parse_bigquery_uri(input_table_uri)
    with bigquery.Client(project=project_id) as client:
      bigquery_job = bigquery_sampler(
          client=client,
          sampler_config=sampler_config,
          input_table_uri=input_table_uri,
          output_table_uri=bigquery_output_table_uri,
      )

      # Early cancellation
      artifact_util.run_bigquery_with_cancellation_propagation(
          sampler_config.execution, bigquery_job, kfp_pipeline_opts)

    # Wrtie to output
    if kfp_pipeline_opts.executor_input:
      write_to_bigquery_output(sampler_config, bigquery_output_table_uri)


def data_splitter_run(argv):
  """Runs pipeline to remove target field in input dataset."""
  splitter_config = _get_config_from_args(argv)
  kfp_pipeline_opts = pipeline_options.KfpOptions(argv)
  data_source = splitter_config.data_source

  if data_source.HasField('gcs_source') or data_source.single_source.HasField(
      'gcs_source'):
    input_files = list(data_source.gcs_source.files) if data_source.HasField(
        'gcs_source') else list(data_source.single_source.gcs_source.files)
    if splitter_config.output.gcs_sink.HasField('path'):
      dataflow_output_path = splitter_config.output.gcs_sink.path
    else:
      pipeline_opts = pipeline_options.ModelEvaluationServiceOptions(argv)
      dataset_root = os.path.join(pipeline_opts.root_dir,
                                  'evaluation_preprocessing')
      os.makedirs(dataset_root, exist_ok=True)
      dataflow_output_path = os.path.join(dataset_root,
                                          constants.Pipeline.SPLITTER_KEY)

    # supported_format: 'CSV', 'JSONL'
    data_format = data_source.gcs_source.format if data_source.HasField(
        'gcs_source') else data_source.single_source.gcs_source.format
    if data_format == configuration_pb2.DataSource.GcsSource.CSV or all(
        ['.csv' in file for file in input_files]):
      input_format = 'CSV'
    elif data_format == configuration_pb2.DataSource.GcsSource.JSONL:
      input_format = 'JSONL'
    else:
      raise UserError('Unsupported data_source.gcs_source.'
                      f'format: {data_format}')

    result = extend_splitter_pipeline(
        splitter_config=splitter_config,
        input_files=input_files,
        input_format=input_format,
        output_path=dataflow_output_path,
    ).run()

    # Early cancellation
    artifact_util.run_with_cancellation_propagation(splitter_config.execution,
                                                    result, kfp_pipeline_opts)

    # Wrtie to output
    if kfp_pipeline_opts.executor_input:
      write_to_gcs_output(splitter_config, dataflow_output_path)
  else:
    input_table_uri = data_source.single_source.bigquery_source.uri

    if splitter_config.output.bigquery_table_uri:
      bigquery_output_table_uri = splitter_config.output.bigquery_table_uri
    else:
      bigquery_output_table_uri = f'{input_table_uri}_{constants.Pipeline.SPLITTER_KEY}_{uuid.uuid4().hex}'

    project_id, _, _ = bigquery_lib.parse_bigquery_uri(input_table_uri)
    with bigquery.Client(project=project_id) as client:
      bigquery_job = bigquery_splitter(
          client=client,
          splitter_config=splitter_config,
          input_table_uri=input_table_uri,
          output_table_uri=bigquery_output_table_uri,
      )

      # Early cancellation
      artifact_util.run_bigquery_with_cancellation_propagation(
          splitter_config.execution, bigquery_job, kfp_pipeline_opts)

    # Wrtie to output
    if kfp_pipeline_opts.executor_input:
      write_to_bigquery_output(splitter_config, bigquery_output_table_uri)
