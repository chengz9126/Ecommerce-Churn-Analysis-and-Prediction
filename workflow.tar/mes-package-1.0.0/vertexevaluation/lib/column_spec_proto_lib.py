"""Util libraries for configuration_pb2.ColumnSpec proto."""
from typing import Optional

from vertexevaluation.proto import configuration_pb2

COLUMN_SPEC_PROTO_DELIMITER = '.'


def build_column_spec(column: str) -> Optional[configuration_pb2.ColumnSpec]:
  """Builds a ColumnSpec given a string separated by delimiter COLUMN_SPEC_PROTO_DELIMITER.

  Args:
    column: String of the path structure for this column spec, separated by
      delimiter COLUMN_SPEC_PROTO_DELIMITER. Example: 'predictions.age'.

  Returns:
    ColumnSpec object for the inputted column string.
    Example:
    ColumnSpec(
      name='predictions',
      sub_column_spec=ColumnSpec(name='age')
    ).
  """
  if not column:
    return None
  specs = column.split(COLUMN_SPEC_PROTO_DELIMITER)
  if not specs:
    return None
  col_spec = configuration_pb2.ColumnSpec(name=specs[-1])
  for spec in specs[-2::-1]:
    col_spec = configuration_pb2.ColumnSpec(name=spec, sub_column_spec=col_spec)
  return col_spec


def build_column_spec_with_prefix(
    column: str, prefix: str) -> Optional[configuration_pb2.ColumnSpec]:
  """Builds a ColumnSpec given a string separated by delimiter COLUMN_SPEC_PROTO_DELIMITER and a prefix.

  Args:
    column: String of the path structure for this column spec, separated by
      delimiter COLUMN_SPEC_PROTO_DELIMITER. Example: 'predictions.age'.
    prefix: The prefix of the column.

  Returns:
    ColumnSpec object for the inputted column string.
    Example:
    ColumnSpec(
      name='predictions',
      sub_column_spec=ColumnSpec(name='age')
    ).
  """
  return build_column_spec(column) if not prefix else build_column_spec(
      '%s%s%s' % (prefix, COLUMN_SPEC_PROTO_DELIMITER, column))


def column_spec_to_string(
    column_spec_proto: configuration_pb2.ColumnSpec) -> str:
  """Flattens a column spec to string joined by COLUMN_SPEC_PROTO_DELIMITER.

  Args:
    column_spec_proto: A ColumnSpec proto message.

  Returns:
    A string joined by COLUMN_SPEC_PROTO_DELIMITER.
    Example:
    predictions.age
  """
  segments = []
  current_column_spec = column_spec_proto
  while current_column_spec.HasField('sub_column_spec'):
    segments.append(current_column_spec.name)
    current_column_spec = current_column_spec.sub_column_spec
  segments.append(current_column_spec.name)
  return COLUMN_SPEC_PROTO_DELIMITER.join(segments)
