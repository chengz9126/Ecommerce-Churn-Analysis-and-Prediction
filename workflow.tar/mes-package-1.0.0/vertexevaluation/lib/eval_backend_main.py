"""Backend binary of the Model Evaluation Service."""

import json
import math
import os
from typing import Any, Dict, Optional

from absl import app
import apache_beam
from google.cloud.aiplatform.metadata.schema.google import artifact_schema
import tensorflow.compat.v1 as tf
from vertexevaluation.error import error
from vertexevaluation.lib import artifact_util
from vertexevaluation.lib import beam as beam_lib
from vertexevaluation.lib import config
from vertexevaluation.lib import constants
from vertexevaluation.lib import pipeline_arg_parser
from vertexevaluation.lib import pipeline_options
from vertexevaluation.proto import configuration_pb2

from google.protobuf import json_format

_USAGE = """
  eval_backend_main --config=<serialized_json>
"""
UserError = error.UserError

_CLASSIFICATION_METRICS = [
    'auPrc',
    'auRoc',
    'logLoss',
]
_REGRESSION_METRICS = [
    'rootMeanSquaredError', 'meanAbsoluteError', 'meanAbsolutePercentageError',
    'rSquared', 'rootMeanSquaredLogError'
]
_FORECASTING_METRICS = _REGRESSION_METRICS + [
    'weightedAbsolutePercentageError',
    'rootMeanSquaredPercentageError',
    'symmetric_mean_absolute_percentage_error',
]
_OUTPUT_METRICS_MAP = {
    'classification': _CLASSIFICATION_METRICS,
    'forecasting': _FORECASTING_METRICS,
    'regression': _REGRESSION_METRICS,
}


def _get_config_from_args(argv) -> configuration_pb2.EvaluationRunConfig:
  """Builds an model evaluation run config.

  Args:
    argv: Arguments received from command line.

  Returns:
    EvaluationRunConfig object for the model evaluation configuration.
  """
  pipeline_opts = pipeline_options.ModelEvaluationServiceOptions(argv)
  if pipeline_opts.batch_prediction_format != 'bigquery':
    _validate_predictions(pipeline_opts.batch_prediction_gcs_source)
  # TODO(ryanguo) add bigquery prediction validation
  if pipeline_opts.config:
    # Config directly provided via "--config" arg
    return json_format.ParseDict(pipeline_opts.config,
                                 configuration_pb2.EvaluationRunConfig())

  elif pipeline_opts.config_gcs_uri:
    # Use GCS as input of the model_eval_json_config.
    with tf.io.gfile.GFile(pipeline_opts.config_gcs_uri, 'rb') as f:
      return json_format.Parse(f.read(),
                               configuration_pb2.EvaluationRunConfig())

  else:
    return pipeline_arg_parser.build_evaluation_config(argv)


def _validate_predictions(batch_prediction_gcs_source: str):
  """Validates the batch predictions in gcs, throw error if they are empty files.

  Args:
    batch_prediction_gcs_source: The batch prediction gcs source.
  """
  if not batch_prediction_gcs_source:
    return
  prediction_files = tf.io.gfile.listdir(batch_prediction_gcs_source)
  if not prediction_files:
    raise UserError('No files in batch prediction source: {}'.format(
        batch_prediction_gcs_source))
  find_valid_file = False
  for prediction_file in prediction_files:
    if tf.io.gfile.stat(
        os.path.join(batch_prediction_gcs_source, prediction_file)).length:
      find_valid_file = True
      break
  if not find_valid_file:
    raise UserError(
        'All {} files are empty in batch prediction source: {}'.format(
            len(prediction_files), batch_prediction_gcs_source))


def _get_metrics_float_value(metrics_dict: Dict[str, Any],
                             key: str) -> Optional[float]:
  """Retrieves the float value from the metrics json if not NaN, INF, or -INF.
  """
  if key not in metrics_dict:
    return None
  try:
    value = float(metrics_dict[key])
  except ValueError:
    return None
  if math.isnan(value) or math.isinf(value):
    return None
  return value


def _write_to_kfp_artifact(
    eval_config: configuration_pb2.EvaluationRunConfig,
    executor_input: str,
    target_artifact_name: str = 'evaluation_metrics') -> None:
  """Writes Metrics to the evaluation_metrics artifact for KFP."""
  # Get output_spec path.
  if eval_config.output.gcs_sink.HasField('path'):
    output_path = os.path.join(eval_config.output.gcs_sink.path,
                               constants.Pipeline.METRICS_KEY)
  else:
    output_path = eval_config.output.gcs_sink.uri

  with tf.io.gfile.GFile(output_path, 'rb') as f:
    eval_metrics = json.load(f)
    if eval_metrics is None or not eval_metrics:
      # Throw error if eval metrics are empty.
      raise app.UsageError('evaluation_metrics were not successfully computed.')

  if eval_config.problem.HasField('classification'):
    problem_type = 'classification'
    metrics = eval_metrics['slicedMetrics'][0]['metrics'][problem_type]
    metrics_artifact = artifact_schema.ClassificationMetrics(
        display_name='evaluation_metrics_classification',
        uri=output_path,
        au_prc=_get_metrics_float_value(metrics, 'auPrc'),
        au_roc=_get_metrics_float_value(metrics, 'auRoc'),
        log_loss=_get_metrics_float_value(metrics, 'logLoss'))
  elif eval_config.problem.HasField('regression'):
    problem_type = 'regression'
    metrics = eval_metrics['slicedMetrics'][0]['metrics'][problem_type]
    metrics_artifact = artifact_schema.RegressionMetrics(
        display_name='evaluation_metrics_regression',
        uri=output_path,
        root_mean_squared_error=_get_metrics_float_value(
            metrics, 'rootMeanSquaredError'),
        mean_absolute_error=_get_metrics_float_value(metrics,
                                                     'meanAbsoluteError'),
        mean_absolute_percentage_error=_get_metrics_float_value(
            metrics, 'meanAbsolutePercentageError'),
        r_squared=_get_metrics_float_value(metrics, 'rSquared'),
        root_mean_squared_log_error=_get_metrics_float_value(
            metrics, 'rootMeanSquaredLogError'))
  elif eval_config.problem.HasField('forecasting'):
    problem_type = 'forecasting'
    metrics = eval_metrics['slicedMetrics'][0]['metrics'][problem_type]
    metrics_artifact = artifact_schema.ForecastingMetrics(
        display_name='evaluation_metrics_forecasting',
        uri=output_path,
        root_mean_squared_error=_get_metrics_float_value(
            metrics, 'rootMeanSquaredError'),
        mean_absolute_error=_get_metrics_float_value(metrics,
                                                     'meanAbsoluteError'),
        mean_absolute_percentage_error=_get_metrics_float_value(
            metrics, 'meanAbsolutePercentageError'),
        r_squared=_get_metrics_float_value(metrics, 'rSquared'),
        root_mean_squared_log_error=_get_metrics_float_value(
            metrics, 'rootMeanSquaredLogError'),
        weighted_absolute_percentage_error=_get_metrics_float_value(
            metrics, 'weightedAbsolutePercentageError'),
        root_mean_squared_percentage_error=_get_metrics_float_value(
            metrics, 'rootMeanSquaredPercentageError'),
        symmetric_mean_absolute_percentage_error=_get_metrics_float_value(
            metrics, 'symmetricMeanAbsolutePercentageError'))
  else:
    raise NotImplementedError('Problem %r not implemented' %
                              eval_config.problem)

  artifact_util.update_output_artifact(executor_input, target_artifact_name,
                                       metrics_artifact)


def evaluation_run(argv):
  """Writes Metrics to the evaluation_metrics artifact for KFP."""
  devel_pipeline_opts = pipeline_options.DevelModelEvaluationServiceOptions(
      argv)
  kfp_pipeline_opts = pipeline_options.KfpOptions(argv)
  eval_config = _get_config_from_args(argv)
  result = beam_lib.append_tfma_pipeline(
      pipeline=apache_beam.Pipeline(
          options=config.get_pipeline_options_from_service_config(
              task_run_name=eval_config.name,
              task_execution_spec=eval_config.execution)),
      model_eval_config=config.get_model_evaluation_config_from_service_config(
          eval_config),
      problem_type=config.get_problem_type_from_service_config(eval_config),
      tfma_format=devel_pipeline_opts.tfma_format,
      json_mode=devel_pipeline_opts.json_mode).run()

  # Early cancellation
  artifact_util.run_with_cancellation_propagation(eval_config.execution, result,
                                                  kfp_pipeline_opts)

  if kfp_pipeline_opts.executor_input:
    _write_to_kfp_artifact(eval_config, kfp_pipeline_opts.executor_input)
