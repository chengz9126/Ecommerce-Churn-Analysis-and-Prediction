"""Artifact util function for writing output parameters."""
import functools
import json
import logging
import os
import re
import sys
from typing import Union

from apache_beam.runners import runner
from google.api_core import exceptions
from google.cloud import bigquery
from google.cloud.aiplatform.metadata.schema.google import artifact_schema
from google_cloud_pipeline_components.container.utils import execution_context
from google_cloud_pipeline_components.proto import gcp_resources_pb2
from googleapiclient import discovery
from kfp.v2.dsl import Artifact
from vertexevaluation.error import error
from vertexevaluation.lib import bigquery_lib
from vertexevaluation.lib import constants
from vertexevaluation.proto import configuration_pb2

from google.protobuf import json_format

DATAFLOW_URI_PATTERN = re.compile(
    r'(https://dataflow.googleapis.com/v1b3/projects/(?P<project>.*)/locations/(?P<location>.*)/jobs/(?P<jobid>.*))'
)
UserError = error.UserError


def run_with_cancellation_propagation(
    execution_spec: configuration_pb2.ExecutionSpec, result, kfp_pipeline_opts):
  """Runs pipeline with early cancellation propagation."""
  gcp_resource_proto = None
  if execution_spec.WhichOneof(
      'spec') == 'dataflow_beam' and kfp_pipeline_opts.gcp_resources:
    dataflowbeam = execution_spec.dataflow_beam
    job_id = result.job_id()
    if job_id:
      gcp_resource_proto = update_gcp_resources(kfp_pipeline_opts,
                                                dataflowbeam.project_id,
                                                dataflowbeam.region, job_id)
  if gcp_resource_proto:
    with execution_context.ExecutionContext(
        on_cancel=functools.partial(
            send_cancel_request, gcp_resource_proto.resources[0].resource_uri)):
      pipeline_state = result.wait_until_finish()
  else:
    pipeline_state = result.wait_until_finish()

  check_internal_error(pipeline_state)


def run_bigquery_with_cancellation_propagation(
    execution_spec: configuration_pb2.ExecutionSpec, job: bigquery.QueryJob,
    kfp_pipeline_opts):
  """Runs BigQuery job with early cancellation propagation."""
  if execution_spec.WhichOneof(
      'spec') == 'dataflow_beam' and kfp_pipeline_opts.gcp_resources:
    job_resources = gcp_resources_pb2.GcpResources()
    job_resource = job_resources.resources.add()
    job_resource.resource_type = 'BigQueryJob'
    job_resource.resource_uri = job.self_link

    # Update the gcp_resources.
    os.makedirs(os.path.dirname(kfp_pipeline_opts.gcp_resources), exist_ok=True)
    with open(kfp_pipeline_opts.gcp_resources, 'w') as f:
      f.write(json_format.MessageToJson(job_resources))

    with execution_context.ExecutionContext(on_cancel=job.cancel):
      bigquery_wait_until_finish(job)
  else:
    bigquery_wait_until_finish(job)


def bigquery_wait_until_finish(job: bigquery.QueryJob):
  """Runs BigQuery job and wait until finished."""
  try:
    job.result()
  except (exceptions.GoogleAPICallError, TypeError) as e:
    bq_permission_err = re.search(bigquery_lib.BQ_PERMISSION_ERR_PATTERN,
                                  str(e))
    if bq_permission_err:
      raise UserError(bigquery_lib.BQ_PERMISSION_ERR_MSG) from e

    logging.exception('Internal Error: Pipeline Failed. %s', e)
    sys.exit(constants.VERTEX_PIPELINE_COMPONENT_FAILURE_CODE)


def check_internal_error(pipeline_state):
  if pipeline_state == runner.PipelineState.FAILED:
    logging.error('Internal Error: Pipeline Failed.')
    sys.exit(constants.VERTEX_PIPELINE_COMPONENT_FAILURE_CODE)


def send_cancel_request(resource_uri):
  """Sends cancellation request to dataflow job.

  Args:
    resource_uri: resource_uri from gcp_resources.
  """
  match = DATAFLOW_URI_PATTERN.match(resource_uri)
  project = match.group('project')
  location = match.group('location')
  job_id = match.group('jobid')
  logging.info('dataflow_cancelling_job_params: %s, %s, %s', project, job_id,
               location)
  df_client = discovery.build('dataflow', 'v1b3', cache_discovery=False)
  job = df_client.projects().locations().jobs().get(
      projectId=project, jobId=job_id, location=location, view=None).execute()
  # Dataflow cancel API:
  # https://cloud.google.com/dataflow/docs/guides/stopping-a-pipeline#stopping_a_job
  job['requestedState'] = 'JOB_STATE_CANCELLED'
  logging.info('dataflow_cancelling_job: %s', job)
  cancelling_job = df_client.projects().locations().jobs().update(
      projectId=project,
      jobId=job_id,
      location=location,
      body=job,
  ).execute()
  logging.info('dataflow_cancelled_job: %s', cancelling_job)
  refreshed_job = df_client.projects().locations().jobs().get(
      projectId=project, jobId=job_id, location=location, view=None).execute()
  logging.info('dataflow_refreshed_job: %s', refreshed_job)


def update_output_artifact(
    executor_input: str, artifact_name: str,
    artifact: Union[Artifact, artifact_schema.ClassificationMetrics,
                    artifact_schema.ForecastingMetrics,
                    artifact_schema.RegressionMetrics]):
  """Update the output evaluation metrics artifact to the executor output."""
  executor_input_json = json.loads(executor_input)
  executor_output = {'artifacts': {}}
  output_artifacts = executor_input_json.get('outputs', {}).get('artifacts', {})

  if artifact_name in output_artifacts.keys():
    # Converts the artifact into executor output artifact
    # https://github.com/kubeflow/pipelines/blob/master/api/v2alpha1/pipeline_spec.proto#L878
    artifacts_list = output_artifacts[artifact_name].get('artifacts')
    if artifacts_list:
      updated_runtime_artifact = artifacts_list[0]
      updated_runtime_artifact['uri'] = artifact.uri
      updated_runtime_artifact['metadata'] = artifact.metadata
      artifacts_list = {'artifacts': [updated_runtime_artifact]}
    executor_output['artifacts'][artifact_name] = artifacts_list

  # Update the output artifacts.
  os.makedirs(
      os.path.dirname(executor_input_json['outputs']['outputFile']),
      exist_ok=True)
  with open(executor_input_json['outputs']['outputFile'], 'w') as f:
    f.write(json.dumps(executor_output))


def update_gcp_resources(kfp_options, project: str, location: str,
                         job_id: str) -> gcp_resources_pb2.GcpResources:
  """Update the gcp_resources with resource information."""
  job_resources = gcp_resources_pb2.GcpResources()
  job_resource = job_resources.resources.add()
  job_resource.resource_type = 'DataflowJob'
  job_resource.resource_uri = f'https://dataflow.googleapis.com/v1b3/projects/{project}/locations/{location}/jobs/{job_id}'

  # Update the gcp_resources.
  os.makedirs(os.path.dirname(kfp_options.gcp_resources), exist_ok=True)
  with open(kfp_options.gcp_resources, 'w') as f:
    f.write(json_format.MessageToJson(job_resources))
  return job_resources
