"""Building an EvaluationRunConfig from individual flags passed in from Pipeline runs.
"""

import json
import os
from typing import Collection, Optional, Sequence, Tuple

from google.api_core import exceptions
from google.cloud import bigquery
from google.cloud.aiplatform_v1.types.model import ModelSourceInfo
import tensorflow.compat.v1 as tf
from vertexevaluation.error import error
from vertexevaluation.lib import bigquery_lib
from vertexevaluation.lib import column_spec_proto_lib
from vertexevaluation.lib import config
from vertexevaluation.lib import constants
from vertexevaluation.lib import json_util
from vertexevaluation.lib import model_lib
from vertexevaluation.lib import pipeline_options
from vertexevaluation.proto import configuration_pb2
from vertexevaluation.proto import preprocessing_pb2

UserError = error.UserError


def _get_gcs_prediction_file(batch_prediction_gcs_source: str) -> str:
  """Gets a prediction file path from the predictions GCS directory.

  Args:
    batch_prediction_gcs_source: directory of the prediction results files.

  Returns:
    prediction_file: a singular prediction results file path.
  Raises:
    UserError: error occurring with there are no prediction files in
    batch_prediction_gcs_source.
  """
  prediction_files = tf.io.gfile.listdir(batch_prediction_gcs_source)
  prediction_file = None
  for filename in prediction_files:
    if [
        valid_prefix for valid_prefix in
        constants.BatchPrediction.VALID_PREDICTION_FILES_PREFIX
        if valid_prefix in filename
    ]:
      prediction_file = os.path.join(batch_prediction_gcs_source, filename)
      break
  if not prediction_file:
    raise UserError(
        'No prediction file found in batch_prediction_gcs_source directory: {}. Valid Prefixes are {}.'
        .format(
            batch_prediction_gcs_source,
            ','.join(constants.BatchPrediction.VALID_PREDICTION_FILES_PREFIX)))
  return prediction_file


def set_default_for_automl_classification_gcs(
    prediction_file: str,
    class_names: Optional[Sequence[str]] = None,
    prediction_label_column: Optional[str] = None,
    prediction_score_column: Optional[str] = None,
) -> Tuple[str, str, Sequence[str]]:
  """Verifies and returns Vertex AutoML Classification defaults in a GCS prediction file.

  Below are the expected outputs for prediction_label_column and
  prediction_score_column if the model is an AutoML Model using the default
  prediction schema. Data type will be searched for in the predictions file.
  AutoML Tabular Classification:
    prediction_label_column: "prediction.classes"
    prediction_score_column: "prediction.scores"
  AutoML Image Classification:
    prediction_label_column: "prediction.displayNames"
    prediction_score_column: "prediction.confidences"
    (NOT CHECKED) prediction_id_column: "prediction.id"
  AutoML Text Classification:
    prediction_label_column: "prediction.displayNames"
    prediction_score_column: "prediction.confidences"
    (NOT CHECKED) prediction_id_column: "prediction.id"
  AutoML Video Classification:
    prediction_label_column: "prediction.displayName"
    prediction_score_column: "prediction.confidence"
    (NOT CHECKED) prediction_id_column: "prediction.id"
  Args:
    prediction_file: string of a results prediction file
    class_names: names of the classes being used in the evaluation run. If not
      provided, will search through defaults for AutoML Classification.
    prediction_label_column: string of the labels for the prediction data. If
      not provided, will search through defaults for AutoML Classification.
    prediction_score_column: string of the labels for the prediction data. If
      not provided, will search through defaults for AutoML Classification.

  Returns:
    prediction_label_column: string of the labels for the prediction data.
    prediction_score_column: string of the scores for the prediction data.
    class_names: list of strings where each element is a class/label name.
  Raises:
    UserError: error occurring with prediction file in the
      batch_prediction_gcs_source directory and/or with class_names.
  """
  default_columns = constants.BatchPrediction.AUTOML_CLASSIFICATION_DEFAULT_COLUMNS_JSONL
  if prediction_label_column and prediction_score_column:
    columns = [(prediction_label_column, prediction_score_column)]
  else:
    columns = default_columns
  with tf.io.gfile.GFile(prediction_file, 'r') as f:
    for line in f:
      # Skip empty line if there is any.
      if not line:
        continue
      try:
        prediction_dict = json.loads(line)
      except json.decoder.JSONDecodeError:
        # Check for CSV format prediction files.
        return (
            'prediction.classes',
            'prediction.scores',
            [
                # CSV prediction column: "male_0_scores", "male_1_scores"
                # comp[-2] is the class name from these columns.
                comp[-2]
                for comp in [col.split('_') for col in line.split(',')]
                if len(comp) >= 3
            ])
      flattened_dict = json_util.flatten_dict(prediction_dict)
      # Get default label_col and score_col from prediction file.
      predict_label_col, predict_score_col = None, None
      for label_col, score_col in columns:
        label_col_exists = any(
            [label_col in keys for keys in flattened_dict.keys()]) or any([
                keys.endswith(label_col.split('.')[-1])
                for keys in flattened_dict.keys()
            ])
        score_col_exists = any(
            [score_col in keys for keys in flattened_dict.keys()]) or any([
                keys.endswith(score_col.split('.')[-1])
                for keys in flattened_dict.keys()
            ])
        if label_col_exists and score_col_exists:
          predict_label_col, predict_score_col = label_col, score_col
          break
      if not predict_label_col or not predict_score_col:
        raise UserError(
            f'Default prediction label column or score column cannot be found in the prediction source {prediction_file}. Please provide them as input arguments.'
        )
      # Check for AutoML Video class_names length.
      if (predict_label_col, predict_score_col) == ('prediction.displayName',
                                                    'prediction.confidence'):
        # Check for AutoML Video Classification case.
        video_class_names_set = set()
        # AutoML Video Classification prediction column is a list of dicts.
        for prediction in prediction_dict['prediction']:
          # Only segment-classification prediction type is used for evaluation.
          if prediction['type'] == 'segment-classification':
            video_class_names_set.add(prediction['displayName'])
        # Sort for unit tests.
        sorted_class_names_list = sorted(video_class_names_set)
        if class_names and video_class_names_set != set(class_names):
          raise UserError(
              'Prediction labels: {} does not match class_names: {}.'.format(
                  sorted_class_names_list, class_names))
        return predict_label_col, predict_score_col, sorted_class_names_list
      else:
        # AutoML Tabular, Image, or Text Classification.
        # Sort for unit tests. Sorted class_names.
        class_names_list = prediction_dict[predict_label_col.split('.')[-2]][
            predict_label_col.split('.')[-1]]
        class_names_list.sort()
        if class_names and set(class_names_list) != set(class_names):
          raise UserError(
              'Prediction labels: {} does not match class_names: {}.'.format(
                  class_names_list, class_names))
        return predict_label_col, predict_score_col, class_names_list
    # Handle the AutoML Tables use case: we don't expect any shard of the
    # predictions to be empty.
    raise UserError(
        'Prediction file provided {} is empty.'.format(prediction_file))


def set_default_for_automl_classification_bigquery(
    bigquery_table_uri: str,
    prediction_label_column: str,
    class_names: Optional[Sequence[str]] = None) -> Sequence[str]:
  """Vertex AutoML Tables default "predicted_<target>.classes" in prediction table.

  Args:
    bigquery_table_uri: string of a results prediction file
    prediction_label_column: string of the labels for the prediction data
    class_names: names of the classes being used in the evaluation run

  Returns:
    prediction_data/class_names: list of strings where each element is a
    class name
  Raises:
    UserError: error occurring with prediction file in batch prediction gcs
      source directory and/or with class_names.
  """
  bq_project, bq_dataset, bq_table = bigquery_lib.parse_bigquery_uri(
      bigquery_table_uri)
  table_name = f'{bq_project}.{bq_dataset}.{bq_table}'
  query_str = f"""SELECT
{prediction_label_column}
FROM
{table_name}
LIMIT
1"""
  query_result = bigquery_lib.query_for_result(bq_project, query_str)
  try:
    prediction_data = list(query_result)[0][0]
  except IndexError as e:
    raise UserError(
        'Prediction table provided does not have class_names.') from e
  if not class_names:
    return prediction_data
  elif prediction_data == class_names:
    return prediction_data
  else:
    raise UserError(
        'Provided class_names does not match prediction files prediction_label_column. class_names: {} prediction table: {} prediction_label_column: {}'
        .format(class_names, bigquery_table_uri, prediction_label_column))
  return class_names


def set_default_for_regression_or_forecasting_gcs(
    prediction_file: str,
    prediction_score_column: str = 'prediction.value',
) -> str:
  """Verifies and returns Regression or Forecasting defaults from a GCS prediction file.

  Below are the expected outputs for prediction_score_column if the model is
  an AutoML Model using the default prediction schema.
  AutoML Tabular Regression:
    prediction_label_column: N/A
    prediction_score_column: "prediction.value"
  AutoML Tabular Forecasting:
    prediction_label_column: N/A
    prediction_score_column: "prediction.value"
  If the model is custom-trained:
    Custom Model Regression:
      prediction_label_column: N/A
      prediction_score_column: "prediction"
    Custom Model Forecasting:
      prediction_label_column: N/A
      prediction_score_column: "prediction"
  For AutoML models, the datatype in "prediction.value" is a float. For Custom
  Models, it can be either a float or a list of float in "prediction" column.
  Example output column schema:
    AutoML {"prediction": {"value": 1.01}}
    Custom {"prediction": [15.96]} or {"prediction": 15.96}
  Args:
    prediction_file: string of a results prediction file
    prediction_score_column: string of the labels for the prediction data

  Returns:
    prediction_score_column: string of the score for the prediction data
  Raises:
    UserError: error occurring with prediction file in the
      batch_prediction_gcs_source directory.
  """
  with tf.io.gfile.GFile(prediction_file, 'r') as f:
    for line in f:
      # Skip empty line if there is any.
      if not line:
        continue
      try:
        prediction_dict = json.loads(line)
        break
      except json.decoder.JSONDecodeError:
        # CSV format prediction files.
        return prediction_score_column
    flattened_dict = json_util.flatten_dict(prediction_dict)
    if prediction_score_column in flattened_dict:
      # prediction_score_column is user-defined or set to AutoML default.
      return prediction_score_column
    elif 'prediction' in flattened_dict or 'prediction.0' in flattened_dict:
      # Custom model default.
      return constants.BatchPrediction.CUSTOM_DEFAULT_SCORE_COLUMN
    else:
      raise UserError(
          'Provided prediction_score_column {} cannot be found in the prediction instance {}.'
          .format(prediction_score_column, prediction_dict))


def set_default_for_regression_forecasting_bigquery(
    bigquery_table_uri: str,
    prediction_score_column: str):
  """Sets the default prediction score column for regression/forecasting predictions in BigQuery Table format.

  Args:
    bigquery_table_uri: string of a results prediction table.
    prediction_score_column: string of prediction score column.

  Returns:
    string of a default prediction_score_column name if unspecified by user.
  Raises:
    UserError: error occurring when the prediction BQ table does not contain the
      default or specified prediction_score_column.
  """
  bq_project, bq_dataset, bq_table = bigquery_lib.parse_bigquery_uri(
      bigquery_table_uri)
  table_name = f'{bq_project}.{bq_dataset}.{bq_table}'

  query_str = f"""SELECT
{prediction_score_column}
FROM
{table_name}
LIMIT
1"""
  try:
    bigquery_lib.query_for_result(bq_project, query_str)
  except exceptions.BadRequest as e:
    raise UserError(
        f'prediction_score_column {prediction_score_column} cannot be found in the BQ prediction source. Please check the input for prediction_score_column.'
        ) from e
  return prediction_score_column


def _check_custom_model_predictions_length_gcs(
    prediction_file: str,
    class_names: Sequence[str],
    prediction_score_column: str = 'prediction') -> None:
  """Checks that the prediction_score_column length matches class_names length.

  Args:
    prediction_file: path of one prediction file given to the eval container.
    class_names: names of the classes being used in the evaluation run.
    prediction_score_column: string of the score column for the prediction data.
      Formatted with '.' as the delimiter.

  Raises:
    UserError: error occurring when the prediction file is empty or incorrect.
  """
  if not class_names or not class_names[0]:
    raise UserError('Class_names must be provided for custom models.')
  with tf.io.gfile.GFile(prediction_file, 'r') as f:
    for line in f:
      # Skip empty line if there is any.
      if not line:
        continue
      try:
        prediction_data = json.loads(line)
        prediction_score_keys = prediction_score_column.split('.')
        for key in prediction_score_keys:
          if isinstance(prediction_data, dict):
            prediction_data = prediction_data[key]
          elif isinstance(prediction_data, list):
            break
          else:
            raise UserError(
                'Unsupported prediction_score_column {} for prediction instance {}.'
                .format(prediction_score_column, json.loads(line)))
        if isinstance(prediction_data, list):
          if len(prediction_data) != len(class_names):
            # Check for AutoML Video class_names length.
            if prediction_data and isinstance(prediction_data[0], dict):
              segment_classification_count = sum([
                  1 if prediction['type'] == 'segment-classification' else 0
                  for prediction in prediction_data
              ])
              if segment_classification_count == len(class_names):
                return
            raise UserError(
                'Array length of prediction scores: {} does not match class_labels: {}.'
                .format(prediction_data, class_names))
          return
        else:
          raise UserError(
              'Unsupported prediction_score_column {} for prediction {}.'
              .format(prediction_score_column, json.loads(line)))
      except KeyError as e:
        raise UserError(
            ('Prediction file provided does not have correct '
             'prediction_score_column {} for prediction instance {}.').format(
                 prediction_score_column, json.loads(line))) from e
    # We don't expect any shard of the predictions to be empty.
    raise UserError(
        'Prediction file provided {} is empty.'.format(prediction_file))


def _check_custom_model_predictions_length_bigquery(
    bigquery_table_uri: str,
    class_names: Sequence[str],
    prediction_score_column: str = 'prediction') -> None:
  """Checks that the custom classification model 'prediction' column length matches class_names length.

  Args:
    bigquery_table_uri: string of a results prediction table
    class_names: names of the classes being used in the evaluation run.
    prediction_score_column: string of the score column for the prediction data.
      Formatted with '.' as the delimiter.

  Raises:
    UserError: error occurring when the prediction table is empty or incorrect.
  """
  bigquery_project, bigquery_dataset, bigquery_table = bigquery_lib.parse_bigquery_uri(bigquery_table_uri)  # pylint: disable=line-too-long
  table_name = f'{bigquery_project}.{bigquery_dataset}.{bigquery_table}'
  query_str = f"""SELECT
{prediction_score_column}
FROM
{table_name}
LIMIT
1"""
  query_result = bigquery_lib.query_for_result(bigquery_project, query_str)
  try:
    prediction_data = json.loads(list(query_result)[0][0])
  except IndexError as e:
    raise UserError(
        'Prediction table provided does not have prediction_score_column {}. '
        .format(prediction_score_column)) from e
  except json.decoder.JSONDecodeError as e:
    raise UserError('Prediction score column from prediction table cannot '
                    'be parsed. Please check the table column type.') from e
  if not isinstance(prediction_data, list) and not isinstance(
      prediction_data, float):
    raise UserError(
        'Prediction table provided does not have prediction_score_column {}.'
        .format(prediction_score_column))
  if (not class_names) or len(prediction_data) != len(class_names):
    raise UserError(
        'Array length of prediction: {} does not match class_names: {}.'.format(
            prediction_data, class_names))


def build_evaluation_config(
    pipeline_args: Sequence[str]) -> configuration_pb2.EvaluationRunConfig:
  """Builds config from multiple command line arguments.

  Args:
    pipeline_args: command line arguments representing individual flags passed
      in from Pipeline runs

  Returns:
    eval_config: configuration needed to model predictions
    from an evaluation dataset
  Raises:
    UserError: An error occurs for unsupported formats
  """
  pipeline_opts = pipeline_options.ModelEvaluationServiceOptions(pipeline_args)
  problem_type_pipeline_opts = pipeline_options.ModelEvaluationServiceTabularOptions(
      pipeline_args)

  # get vertex model source type
  model_source_type = model_lib.get_vertex_model_source_type(
      pipeline_opts.model_name)

  # TODO(kevinbnaughton): Improve this code since we code provide a uri or a
  # path. explanation_gcs_path could need to be updated too.
  if pipeline_opts.generate_feature_attribution:
    explanation_path = '/'.join(
        pipeline_opts.output_metrics_gcs_path.split('/')[0:-1])
    output_spec = configuration_pb2.OutputSpec(
        gcs_sink=configuration_pb2.GcsSink(
            uri=pipeline_opts.output_metrics_gcs_path),
        explanation_gcs_path=explanation_path + '/feature_importance.json')
  else:
    output_spec = configuration_pb2.OutputSpec(
        gcs_sink=configuration_pb2.GcsSink(
            uri=pipeline_opts.output_metrics_gcs_path))
  # TODO(ryanguo): Find better method to avoid this hard coded logic for BQ.
  # In pipeline yaml file, `instance` prefix has been added to
  # target_field_name for jsonl format prediction by default. For BQ
  # target_field_name, we need to remove the instance prefix.
  target_field_name = problem_type_pipeline_opts.target_field_name
  if pipeline_opts.batch_prediction_format == 'bigquery' and len(
      target_field_name.split('.')) > 1 and target_field_name.split(
          '.')[0] == 'instance':
    target_field_name = '.'.join(target_field_name.split('.')[1:])

  if pipeline_opts.problem_type == 'classification':
    classification_type = configuration_pb2.ClassificationProblemSpec.MULTILABEL if problem_type_pipeline_opts.classification_type == 'multilabel' else configuration_pb2.ClassificationProblemSpec.MULTICLASS
    if pipeline_opts.batch_prediction_format != 'bigquery':
      prediction_file = _get_gcs_prediction_file(
          pipeline_opts.batch_prediction_gcs_source)
      # Get defaults for GCS output from Batch Prediction, for AutoML Models.
      if model_source_type.value == ModelSourceInfo.ModelSourceType.AUTOML:
        prediction_label_column, prediction_score_column, class_names = set_default_for_automl_classification_gcs(
            prediction_file=prediction_file,
            class_names=problem_type_pipeline_opts.class_names
            if problem_type_pipeline_opts.class_names else None,
            prediction_label_column=problem_type_pipeline_opts  # pylint: disable=g-long-ternary
            .prediction_label_column
            if problem_type_pipeline_opts.prediction_label_column else None,
            prediction_score_column=problem_type_pipeline_opts
            .prediction_score_column
            if problem_type_pipeline_opts.prediction_score_column else None)
      else:
        # class_names must be provided with following model source type
        # aiplatform_v1.ModelSourceInfo.ModelSourceType.MODEL_SOURCE_TYPE_UNSPECIFIED
        # aiplatform_v1.ModelSourceInfo.ModelSourceType.CUSTOM
        # aiplatform_v1.ModelSourceInfo.ModelSourceType.BQML
        class_names = problem_type_pipeline_opts.class_names
        prediction_label_column = problem_type_pipeline_opts.prediction_label_column if problem_type_pipeline_opts.prediction_label_column else None
        prediction_score_column = problem_type_pipeline_opts.prediction_score_column if problem_type_pipeline_opts.prediction_score_column else 'prediction'
        _check_custom_model_predictions_length_gcs(
            prediction_file=prediction_file,
            class_names=class_names,
            prediction_score_column=prediction_score_column)
    else:
      # AutoML Model BigQuery prediction source uses:
      # 'predicted_<target_field_name>.scores' and
      # 'predicted_<target_field_name>.classes' as defaults.
      if model_source_type.value == ModelSourceInfo.ModelSourceType.AUTOML:
        prediction_label_column = problem_type_pipeline_opts.prediction_label_column if problem_type_pipeline_opts.prediction_label_column else f'predicted_{target_field_name}.classes'
        prediction_score_column = problem_type_pipeline_opts.prediction_score_column if problem_type_pipeline_opts.prediction_score_column else f'predicted_{target_field_name}.scores'
        class_names = set_default_for_automl_classification_bigquery(
            bigquery_table_uri=pipeline_opts.batch_prediction_bigquery_source,
            prediction_label_column=prediction_label_column,
            class_names=problem_type_pipeline_opts.class_names
            if problem_type_pipeline_opts.class_names else None)
      else:
        # Custom Model BigQuery prediction source uses:
        # 'prediction' as prediction score column default.
        # class_names must be provided with following model source type
        # aiplatform_v1.ModelSourceInfo.ModelSourceType.MODEL_SOURCE_TYPE_UNSPECIFIED
        # aiplatform_v1.ModelSourceInfo.ModelSourceType.CUSTOM
        # aiplatform_v1.ModelSourceInfo.ModelSourceType.BQML
        class_names = problem_type_pipeline_opts.class_names
        prediction_label_column = problem_type_pipeline_opts.prediction_label_column if problem_type_pipeline_opts.prediction_label_column else None
        prediction_score_column = problem_type_pipeline_opts.prediction_score_column if problem_type_pipeline_opts.prediction_score_column else 'prediction'
        _check_custom_model_predictions_length_bigquery(
            bigquery_table_uri=pipeline_opts.batch_prediction_bigquery_source,
            prediction_score_column=prediction_score_column,
            class_names=class_names)
    slicing_opts = pipeline_options.SlicingOptions(pipeline_args)
    if slicing_opts.slice_columns:
      slice_options = [
          # pylint: disable=g-complex-comprehension
          configuration_pb2.ClassificationProblemSpec.SlicingOptions(slices=[
              configuration_pb2.ClassificationProblemSpec.SlicingOptions.Slice(
                  slice_columns=column_spec_proto_lib.build_column_spec(
                      slicing_opts.slice_columns[i][s]),
                  features=[  # pylint: disable=g-long-ternary
                      configuration_pb2.ClassificationProblemSpec.SlicingOptions
                      .Slice.Feature(
                          name=column_spec_proto_lib
                          .build_column_spec(slicing_opts.slice_features[i][s]),
                          value=slicing_opts.feature_values[i][s])
                  ] if slicing_opts.slice_features else None)
              for s in range(len(slicing_opts.slice_columns[i]))
          ])
          for i in range(len(slicing_opts.slice_columns))
      ]
      # eval options predicts top_k slices and are omitted when
      # slice config is provided
      eval_options = None
    else:
      eval_options = configuration_pb2.ClassificationProblemSpec.EvaluationOptions(
          top_k_list=problem_type_pipeline_opts.top_k_list
          if problem_type_pipeline_opts.top_k_list else [1],
          positive_classes=problem_type_pipeline_opts.positive_classes
          if problem_type_pipeline_opts.positive_classes else class_names,
          decision_thresholds=problem_type_pipeline_opts.decision_thresholds
          if problem_type_pipeline_opts.decision_thresholds else None)
      slice_options = None
    fair_slices = [
        configuration_pb2.ClassificationProblemSpec.FairnessOptions
        .FairnessSlice(slices=[])
    ]
    for f_slice in problem_type_pipeline_opts.fairness_slices:
      slice_columns = []
      for feature in f_slice:
        slice_columns.append(column_spec_proto_lib.build_column_spec(feature))
      slices = configuration_pb2.ClassificationProblemSpec.FairnessOptions.FairnessSlice(
          slices=slice_columns)
      fair_slices.append(slices)
    fair_options = configuration_pb2.ClassificationProblemSpec.FairnessOptions(
        fairness_slices=fair_slices,
        fairness_thresholds=problem_type_pipeline_opts.fairness_thresholds
        if problem_type_pipeline_opts.fairness_thresholds else None,
        confidence_intervals=problem_type_pipeline_opts
        .compute_confidence_intervals
        if problem_type_pipeline_opts.compute_confidence_intervals else None)
    problem_spec = configuration_pb2.ProblemSpec(
        classification=configuration_pb2.ClassificationProblemSpec(
            class_names=class_names,
            ground_truth_column_spec=column_spec_proto_lib.build_column_spec(
                target_field_name),
            prediction_label_column_spec=column_spec_proto_lib
            .build_column_spec(prediction_label_column
                              ) if prediction_label_column else None,
            prediction_score_column_spec=column_spec_proto_lib
            .build_column_spec(prediction_score_column),
            prediction_id_column_spec=column_spec_proto_lib.build_column_spec(
                problem_type_pipeline_opts.prediction_id_column
            ) if problem_type_pipeline_opts.prediction_id_column else None,
            type=classification_type,
            evaluation_options=eval_options,
            slicing_options=slice_options,
            fairness_options=fair_options if problem_type_pipeline_opts
            .compute_fairness else None))
  elif pipeline_opts.problem_type == 'regression':
    prediction_score_column = problem_type_pipeline_opts.prediction_score_column
    if pipeline_opts.batch_prediction_format != 'bigquery':
      # Provide Vertex defaults for different model source types.
      if model_source_type.value == ModelSourceInfo.ModelSourceType.AUTOML:
        prediction_score_column = prediction_score_column if prediction_score_column else 'prediction.value'
      else:
        prediction_score_column = prediction_score_column if prediction_score_column else 'prediction'
      prediction_score_column = set_default_for_regression_or_forecasting_gcs(
          prediction_file=_get_gcs_prediction_file(
              pipeline_opts.batch_prediction_gcs_source),
          prediction_score_column=prediction_score_column)
    else:
      # BQ prediction source.
      if model_source_type.value == ModelSourceInfo.ModelSourceType.AUTOML:
        prediction_score_column = prediction_score_column if prediction_score_column else f'predicted_{target_field_name}.value'
      else:
        prediction_score_column = prediction_score_column if prediction_score_column else 'prediction'
      prediction_score_column = set_default_for_regression_forecasting_bigquery(
          bigquery_table_uri=pipeline_opts.batch_prediction_bigquery_source,
          prediction_score_column=prediction_score_column)
    problem_spec = configuration_pb2.ProblemSpec(
        regression=configuration_pb2.RegressionProblemSpec(
            ground_truth_column_spec=column_spec_proto_lib.build_column_spec(
                target_field_name),
            prediction_score_column_spec=column_spec_proto_lib
            .build_column_spec(prediction_score_column),
            example_weight_column_spec=column_spec_proto_lib
            .build_column_spec(problem_type_pipeline_opts.example_weight_column)
            if problem_type_pipeline_opts.example_weight_column else None))
  elif pipeline_opts.problem_type == 'forecasting':
    prediction_score_column = problem_type_pipeline_opts.prediction_score_column
    if pipeline_opts.batch_prediction_format != 'bigquery':
      # Provide Vertex defaults if empty for prediction_score_column.
      # Provide Vertex defaults for different model source types.
      if model_source_type.value == ModelSourceInfo.ModelSourceType.AUTOML:
        prediction_score_column = prediction_score_column if prediction_score_column else 'prediction.value'
      else:
        prediction_score_column = prediction_score_column if prediction_score_column else 'prediction'
      prediction_score_column = set_default_for_regression_or_forecasting_gcs(
          prediction_file=_get_gcs_prediction_file(
              pipeline_opts.batch_prediction_gcs_source),
          prediction_score_column=prediction_score_column)
    else:
      # BQ prediction source.
      if model_source_type.value == ModelSourceInfo.ModelSourceType.AUTOML:
        prediction_score_column = prediction_score_column if prediction_score_column else f'predicted_{target_field_name}.value'
      else:
        prediction_score_column = prediction_score_column if prediction_score_column else 'prediction'
      prediction_score_column = set_default_for_regression_forecasting_bigquery(
          bigquery_table_uri=pipeline_opts.batch_prediction_bigquery_source,
          prediction_score_column=prediction_score_column)
    if problem_type_pipeline_opts.forecasting_type.lower() == 'point':
      forecasting_type = configuration_pb2.ForecastingProblemSpec.POINT
    elif problem_type_pipeline_opts.forecasting_type.lower() == 'quantile':
      forecasting_type = configuration_pb2.ForecastingProblemSpec.QUANTILE
    else:
      raise UserError('Invalid forecasting type: {}'.format(
          problem_type_pipeline_opts.forecasting_type))
    problem_spec = configuration_pb2.ProblemSpec(
        forecasting=configuration_pb2.ForecastingProblemSpec(
            ground_truth_column_spec=column_spec_proto_lib.build_column_spec(
                target_field_name),
            prediction_score_column_spec=column_spec_proto_lib
            .build_column_spec(prediction_score_column),
            example_weight_column_spec=column_spec_proto_lib
            .build_column_spec(problem_type_pipeline_opts.example_weight_column)
            if problem_type_pipeline_opts.example_weight_column else None,
            type=forecasting_type,
            quantiles=problem_type_pipeline_opts.forecasting_quantiles,
            options=configuration_pb2.ForecastingProblemSpec
            .ForecastingEvaluationOptions(
                enable_point_evaluation=problem_type_pipeline_opts
                .point_evaluation_quantile_index is not None,
                point_evaluation_quantile_index=problem_type_pipeline_opts
                .point_evaluation_quantile_index,
            )))
  else:
    if pipeline_opts.problem_type:
      raise NotImplementedError('Invalid problem type: {}'.format(
          pipeline_opts.problem_type))
    else:
      raise ValueError('No problem type provided')
  eval_config = configuration_pb2.EvaluationRunConfig(
      name=pipeline_opts.display_name,
      data_source=build_data_source(pipeline_args, target_field_name),
      problem=problem_spec,
      output=output_spec,
      execution=build_execution_spec(pipeline_args))
  config.validate_service_config(eval_config)
  return eval_config


def _parse_data_format(format_):
  """Reads data format from pipeline options and casts to existing format."""
  if format_ == 'jsonl':
    return configuration_pb2.DataSource.GcsSource.Format.JSONL
  elif format_ == 'csv':
    return configuration_pb2.DataSource.GcsSource.Format.CSV
  elif format_ == 'bigquery':
    # TODO(b/244471008): replace `bq` after proto refactor
    return 'bq'
  else:
    raise UserError('Unsupported data format: {}'.format(format_))


def get_key_columns_from_gcs(ground_truth_file: str, target_field_name: str):
  """Extracts key_columns from ground_truth GCS file.

  Args:
    ground_truth_file: a string of GCS file uri where ground truth dataset is
      located.
    target_field_name: a string of target fields column name.

  Returns:
    A list of all features except target_field_name.

  Raises:
    UserError: error occuring when ground truth file is empty or does not
    contain target_field_name.
  """
  with tf.io.gfile.GFile(ground_truth_file, 'r') as f:
    for line in f.read().splitlines():
      # Skip empty line if there is any.
      if not line:
        continue
      try:
        instance_dict = json.loads(line)
      except json.decoder.JSONDecodeError:
        # CSV format file.
        try:
          key_columns = line.replace('"', '').split(',')
          key_columns.remove(target_field_name)
          return key_columns
        except ValueError:
          raise UserError(
              f'Ground truth CSV file {ground_truth_file} does not contain target_field_name {target_field_name}.'
          ) from None
      # JSONL format file.
      try:
        key_columns = list(instance_dict.keys())
        key_columns.remove(target_field_name)
        return key_columns
      except ValueError:
        raise UserError(
            f'Ground truth JSONL file {ground_truth_file} does not contain target_field_name {target_field_name}.'
        ) from None
    raise UserError(
        'Ground truth file provided {} is empty.'.format(ground_truth_file))


def get_key_columns_from_bq(ground_truth_bq_uri: str, target_field_name: str):
  """Extracts key_columns from ground_truth BQ Table URI.

  Args:
    ground_truth_bq_uri: a string of BQ Table uri where ground truth dataset is
      located.
    target_field_name: a string of target fields column name.

  Returns:
    A list of all feature columns except target_field_name.

  Raises:
    UsageError: error occuring when ground truth file is empty or does not
      contain target_field_name.
  """
  schema_list = bigquery_lib.check_if_table_exists_and_get_schema(
      ground_truth_bq_uri)
  key_columns = []
  for column in schema_list:
    if isinstance(column, bigquery.schema.SchemaField):
      col_name = column.name
    else:  # column is Mapping[str, Any].
      col_name = column.get('name')
    if col_name != target_field_name:
      key_columns.append(col_name)
  return key_columns


def build_data_source(
    pipeline_args: Sequence[str],
    target_field_name: Optional[str] = None) -> configuration_pb2.DataSource:
  """Builds data source from command line arguments.

  Args:
    pipeline_args: List of string command line arguments
    target_field_name: a string of target fields column name. Prefixed with
      "instance." for joining JSONL ground truth files.

  Returns:
    data_source:  Config representing where to read data in beam pipelines
  """
  pipeline_opts = pipeline_options.ModelEvaluationServiceOptions(pipeline_args)
  ground_truth_files = list(
      filter(lambda file: file, pipeline_opts.ground_truth_gcs_source))
  ground_truth_bq_uri = pipeline_opts.ground_truth_bigquery_source
  prediction_files = list(
      filter(lambda file: file, pipeline_opts.batch_prediction_gcs_source))
  prediction_bq_uri = pipeline_opts.batch_prediction_bigquery_source
  batch_prediction_format = _parse_data_format(
      pipeline_opts.batch_prediction_format)
  ground_truth_format = _parse_data_format(pipeline_opts.ground_truth_format)

  # TODO(b/244471008): replace `bq` after proto refactor
  if prediction_files and batch_prediction_format != 'bq':
    prediction_data = configuration_pb2.DataSource.Source(
        gcs_source=configuration_pb2.DataSource.GcsSource(
            format=batch_prediction_format,
            files=[
                os.path.join(pipeline_opts.batch_prediction_gcs_source,
                             f'{valid_prefix}*') for valid_prefix in
                constants.BatchPrediction.VALID_PREDICTION_FILES_PREFIX
            ]))
  elif prediction_bq_uri and batch_prediction_format == 'bq':
    prediction_data = configuration_pb2.DataSource.Source(
        bigquery_source=configuration_pb2.DataSource.BigquerySource(
            uri=prediction_bq_uri))
  else:
    raise UserError('No valid prediction source provided')

  # Remove "instance." prefix if exists.
  if target_field_name and target_field_name.startswith('instance.'):
    target_field_name = target_field_name[len('instance.'):]

  if ground_truth_files and ground_truth_format != 'bq':
    ground_truth_data = configuration_pb2.DataSource.Source(
        gcs_source=configuration_pb2.DataSource.GcsSource(
            format=ground_truth_format, files=ground_truth_files))
    key_columns = get_key_columns_from_gcs(ground_truth_files[0],
                                           target_field_name)
  elif ground_truth_bq_uri and ground_truth_format == 'bq':
    ground_truth_data = configuration_pb2.DataSource.Source(
        bigquery_source=configuration_pb2.DataSource.BigquerySource(
            uri=ground_truth_bq_uri))
    key_columns = get_key_columns_from_bq(ground_truth_bq_uri,
                                          target_field_name)
  else:
    ground_truth_data = None
  if ground_truth_data:
    key_prefix_in_prediction_dataset = 'instance' if batch_prediction_format == configuration_pb2.DataSource.GcsSource.Format.JSONL else ''
    return configuration_pb2.DataSource(
        joining_source=configuration_pb2.DataSource.JoiningSource(
            prediction_data=prediction_data,
            ground_truth_data=ground_truth_data,
            key_prefix_in_prediction_dataset=column_spec_proto_lib
            .build_column_spec(key_prefix_in_prediction_dataset),
            key_columns=[
                column_spec_proto_lib.build_column_spec(key_column)
                for key_column in key_columns
            ]))
  else:
    return configuration_pb2.DataSource(single_source=prediction_data)


def build_execution_spec(
    args: Sequence[str]) -> configuration_pb2.ExecutionSpec:
  """Builds execution spec from multiple Model Evaluation Service Options.

  Args:
    args: List of string command line arguments

  Returns:
    execution_spec: execution spec for configuration needed to model predictions
    from an evaluation dataset
  """
  pipeline_opts = pipeline_options.ModelEvaluationServiceOptions(args)
  if not pipeline_opts.project_id:
    return configuration_pb2.ExecutionSpec(
        local_beam=configuration_pb2.LocalBeam(num_workers=1))
  dataflow_pipeline_opts = pipeline_options.ModelEvaluationServiceDataflowOptions(
      args)

  def format_root_dir(directory: str) -> str:
    if directory[0:5] == 'gs://':
      # For GCS.
      root_dir = directory[0:5] + str(os.path.join(*directory[5:].split('/')))
    else:
      # For unit tests.
      root_dir = '/' + str(os.path.join(*directory.split('/')))
    return root_dir.rstrip('/')

  root_dir = format_root_dir(pipeline_opts.root_dir)
  return configuration_pb2.ExecutionSpec(
      dataflow_beam=configuration_pb2.DataflowBeam(
          dataflow_job_prefix=dataflow_pipeline_opts.dataflow_job_prefix,
          project_id=pipeline_opts.project_id,
          service_account=dataflow_pipeline_opts.dataflow_service_account
          if dataflow_pipeline_opts.dataflow_service_account else None,
          dataflow_staging_dir=root_dir + '/dataflow_staging/',
          dataflow_temp_dir=root_dir + '/dataflow_temp/',
          num_workers=dataflow_pipeline_opts.dataflow_workers_num,
          max_num_workers=dataflow_pipeline_opts.dataflow_max_workers_num,
          machine_type=dataflow_pipeline_opts.dataflow_machine_type,
          disk_size_gb=dataflow_pipeline_opts.dataflow_disk_size,
          region=pipeline_opts.location,
          kms_key_name=dataflow_pipeline_opts.kms_key_name,
          worker_container_image=dataflow_pipeline_opts
          .dataflow_worker_container_image,
          subnetwork=configuration_pb2.DataflowBeam.Subnetwork(
              name=dataflow_pipeline_opts.dataflow_subnetwork,
              use_public_ips=dataflow_pipeline_opts.dataflow_use_public_ips)))


def validate_gcs_uris(gcs_source: Collection[str]) -> None:
  """Validates GCS source by checking for empty GCS file.

  Args:
    gcs_source: a list of GCS uri for prediction_source or ground_truth_source
      or dataset_source.

  Raises:
    UserError: error occurring when data source is empty or there are no
      files in data source.
  """
  if not gcs_source:
    raise UserError('Please provide a valid GCS source.')

  for file_uri in gcs_source:
    if not tf.io.gfile.exists(file_uri):
      raise UserError('GCS source does not exist: {}'.format(file_uri))
    if not tf.io.gfile.stat(file_uri).length:
      raise UserError('GCS source {} contains empty file.'.format(file_uri))


def build_preprocessing_data_source(
    preprocessing_opts: pipeline_options.PreprocessingServiceOptions
) -> Tuple[configuration_pb2.DataSource, configuration_pb2.OutputSpec]:
  """Builds preprocessing data source and output specification.

  Args:
    preprocessing_opts: Options supplied by preprocessing component service.

  Returns:
    A tuple of DataSource proto and OutputSpec proto.
  Raises:
    UserError: error occurring when no valid input source is provided.
  """
  instances_format = _parse_data_format(preprocessing_opts.instances_format)

  if preprocessing_opts.gcs_source_uris and instances_format != 'bq':
    # JSONL or CSV format.
    validate_gcs_uris(preprocessing_opts.gcs_source_uris)

    data_source = configuration_pb2.DataSource(
        single_source=configuration_pb2.DataSource.Source(
            gcs_source=configuration_pb2.DataSource.GcsSource(
                format=instances_format,
                files=preprocessing_opts.gcs_source_uris)))
    output_spec = configuration_pb2.OutputSpec(
        gcs_sink=configuration_pb2.GcsSink(
            uri=preprocessing_opts.gcs_directory_for_gcs_output_uris),
        bigquery_output_directory=preprocessing_opts
        .gcs_directory_for_bigquery_output_table_uri)

  elif preprocessing_opts.bigquery_source_uri and instances_format == 'bq':
    # BigQuery format.
    bigquery_lib.check_if_table_exists_and_get_schema(
        preprocessing_opts.bigquery_source_uri)

    data_source = configuration_pb2.DataSource(
        single_source=configuration_pb2.DataSource.Source(
            bigquery_source=configuration_pb2.DataSource.BigquerySource(
                uri=preprocessing_opts.bigquery_source_uri)))
    output_spec = configuration_pb2.OutputSpec(
        gcs_sink=configuration_pb2.GcsSink(
            uri=preprocessing_opts.gcs_directory_for_gcs_output_uris),
        bigquery_table_uri=preprocessing_opts.bigquery_output_uri,
        bigquery_output_directory=preprocessing_opts
        .gcs_directory_for_bigquery_output_table_uri)
  else:
    raise UserError('No valid input source provided.')

  return data_source, output_spec


def build_preprocessing_config(
    pipeline_args) -> preprocessing_pb2.PreprocessingRunConfig:
  """Builds preprocessing component config from multiple command line arguments.
  """

  preprocessing_opts = pipeline_options.PreprocessingServiceOptions(
      pipeline_args)
  pipeline_opts = pipeline_options.ModelEvaluationServiceOptions(pipeline_args)
  tabular_opts = pipeline_options.ModelEvaluationServiceTabularOptions(
      pipeline_args)

  data_source, output_spec = build_preprocessing_data_source(preprocessing_opts)

  preprocessing_config = preprocessing_pb2.PreprocessingRunConfig(
      name=pipeline_opts.display_name,
      data_source=data_source,
      output=output_spec,
      execution=build_execution_spec(pipeline_args),
      sample_size=preprocessing_opts.sample_size,
      target_field_name=tabular_opts.target_field_name)
  config.validate_preprocessing_config(preprocessing_config)
  return preprocessing_config
