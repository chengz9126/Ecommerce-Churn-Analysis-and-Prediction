"""Beam function for converting CSV Batch Prediction Outputs to JSONL."""

import json
import os
import re
from typing import Iterable, List

import apache_beam as beam
import tensorflow as tf
from vertexevaluation.lib import constants


def get_headers_from_file(files: List[str]) -> List[str]:
  dirname = os.path.dirname(files[0])
  filenames = [
      os.path.join(dirname, filename)
      for filename in tf.io.gfile.listdir(dirname)
      if re.search(files[0], os.path.join(dirname, filename))
  ]
  with tf.io.gfile.GFile(filenames[0], 'r') as f:
    return f.readline().split(',')


class CsvToJsonl(beam.DoFn):
  """Converts Batch Prediction CSV to JSONL."""

  def __init__(self, headers: List[str], problem_type: constants.ProblemType):
    """Construct the beam function.

    Args:
      headers: List of headers that are found on the first row of the file
      problem_type: The type of ML problem e.g. MULTICLASS.
    """
    self._headers = headers
    self._is_classification = problem_type in set([
        constants.ProblemType.MULTICLASS,
        constants.ProblemType.MULTILABEL,
    ])

  def process(self, input_data: str) -> Iterable[bytes]:
    output_json = {
        'instance': {},
        'prediction': {},
    }

    if self._is_classification:
      output_json['prediction']['scores'] = []
      output_json['prediction']['classes'] = []

    for key, value in zip(self._headers, input_data.split(',')):
      if not self._is_classification and key.startswith(
          'predicted_') and key == self._headers[-1]:
        output_json['prediction'] = {'value': float(value)}
        break
      if self._is_classification and len(key.split('_')) >= 3:
        *_, class_, _ = key.split('_')
        output_json['prediction']['scores'].append(float(value))
        output_json['prediction']['classes'].append(class_)
      else:
        output_json['instance'][key] = value

    yield bytes(json.dumps(output_json), 'utf-8')
