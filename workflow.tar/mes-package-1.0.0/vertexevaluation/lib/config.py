"""Builds configurations for running metrics."""

import os
from typing import List, Optional, Text

from apache_beam.options import pipeline_options as pipeline_opts_lib
from tensorflow_model_analysis.proto import config_pb2
from vertexevaluation.error import error
from vertexevaluation.lib import column_spec
from vertexevaluation.lib import constants
from vertexevaluation.lib import evaluation_column_specs as ecs
from vertexevaluation.lib import quantile_accuracy
from vertexevaluation.lib import tfma_adapter
from vertexevaluation.lib import tfma_metrics
from vertexevaluation.lib.constants import Metric
from vertexevaluation.proto import configuration_pb2
from vertexevaluation.proto import model_evaluation_pb2
from vertexevaluation.proto import preprocessing_pb2

from google.protobuf import message

ColumnSpec = column_spec.ColumnSpec
EvaluationColumnSpecs = ecs.EvaluationColumnSpecs
Metric = constants.Metric
Thresholds = constants.Thresholds
UserError = error.UserError

CLASSIFICATION_METRICS = [
    Metric.AUC,
    Metric.AUC_PRECISION_RECALL,
    Metric.CONFUSION_MATRIX,
    Metric.EXAMPLE_COUNT,
    Metric.WEIGHTED_EXAMPLE_COUNT,
    Metric.BINARY_ACCURACY,
    Metric.BINARY_CROSSENTROPY,
    Metric.CATEGORICAL_ACCURACY,
    Metric.CATEGORICAL_CROSSENTROPY,
    Metric.MULTI_CLASS_CONFUSION_MATRIX,
]

REGRESSION_METRICS = [
    Metric.ACCURACY,
    Metric.EXAMPLE_COUNT,
    Metric.MEAN_ABSOLUTE_ERROR,
    Metric.MEAN_ABSOLUTE_PERCENTAGE_ERROR,
    Metric.MEAN_SQUARED_LOG_ERROR,
    Metric.MEAN_SQUARED_PERCENTAGE_ERROR,
    Metric.ROOT_MEAN_SQUARED_ERROR,
    Metric.R_SQUARED,
    Metric.WEIGHTED_EXAMPLE_COUNT,
    Metric.WEIGHTED_ABSOLUTE_PERCENTAGE_ERROR,
]

POINT_FORECASTING_METRICS = (
    Metric.ACCURACY,
    Metric.EXAMPLE_COUNT,
    Metric.MEAN_ABSOLUTE_ERROR,
    Metric.MEAN_ABSOLUTE_PERCENTAGE_ERROR,
    Metric.MEAN_SQUARED_LOG_ERROR,
    Metric.MEAN_SQUARED_PERCENTAGE_ERROR,
    Metric.ROOT_MEAN_SQUARED_ERROR,
    Metric.R_SQUARED,
    Metric.WEIGHTED_EXAMPLE_COUNT,
    Metric.WEIGHTED_ABSOLUTE_PERCENTAGE_ERROR,
)

QUANTILE_FORECASTING_METRICS = (Metric.QUANTILE_ACCURACY,)

ENV_SETUP_FILE = os.environ.get(constants.Pipeline.ENV_VAR_SETUP, None)


def _get_metric_specs_classification_regression(
    problem_type: constants.ProblemType,
    class_names: Optional[List[Text]] = None,
    positive_class_names: Optional[List[Text]] = None,
    top_k_list: Optional[List[int]] = None,
    fairness_thresholds: Optional[List[float]] = None
) -> List[config_pb2.MetricsSpec]:
  """Builds predfined list of metrics for classification/regression problem types.

  Args:
    problem_type: One of the ProblemType enum.
    class_names: For classification problems, the names of the classes.
    positive_class_names: For classification problems, the positively valued
      classes.
    top_k_list: For classification problems, the list of top-k values.
    fairness_thresholds: For classification problems, the threshold(s) set for
      fairness indicators.

  Returns:
    A list of MetricSpec values.

  Raises:
    UserError: error occurring when user provided inputs are invalid.
    ValueError: internal error related to setting default AutoML class names.
  """
  if problem_type == constants.ProblemType.MULTICLASS:
    if not class_names:
      raise ValueError('Multiclass problem requires a list of class names: {}')
    metric_names = CLASSIFICATION_METRICS.copy()
    is_multi_label = False
    class_weights = None
  elif problem_type == constants.ProblemType.MULTILABEL:
    if not class_names or len(class_names) < 2:
      raise UserError(
          'Multilabel problem requires 2 or more class names: {}'.format(
              class_names))
    metric_names = CLASSIFICATION_METRICS.copy()
    is_multi_label = True
    # TODO(b/171963359): Permit user-configured class weights other than flat.
    class_weights = {class_id: 1.0 for class_id in range(0, len(class_names))}
  elif problem_type == constants.ProblemType.REGRESSION:
    metric_names = REGRESSION_METRICS.copy()
    is_multi_label = False
    class_weights = None

  if class_names and len(class_names) == 1:
    # Binary classification
    # "True" (index 1) represents positive class.
    positive_class_ids = [constants.Data.BINARY_CLASSIFICATION_LABEL_IDS[1]]
  elif class_names and positive_class_names:
    positive_class_ids = [
        class_names.index(class_name) for class_name in positive_class_names
    ]
  else:
    positive_class_ids = None
  metric_specs = tfma_metrics.get_metric_specs(
      metric_names=metric_names,
      is_multi_label=is_multi_label,
      positive_class_ids=positive_class_ids,
      top_k_list=top_k_list,
      custom_metric_map=None,
      class_weights=class_weights,
      fairness_thresholds=fairness_thresholds)
  return metric_specs


def _get_tfma_slicing_specs(
    feature_slices: List[
        configuration_pb2.ClassificationProblemSpec.SlicingOptions.Slice]
) -> List[config_pb2.SlicingSpec]:
  """Builds TFMA Slicing Spec values from feature lists.

  Args:
    feature_slices: List of slices, each being a list of feature keys.

  Returns:
    A list of SlicingSpec values, including the overall slice.
  """
  # Overall Slice:
  slicing_specs = [config_pb2.SlicingSpec()]
  # Per specified slice_columns:
  for slices in feature_slices:
    if slices:
      slicing_spec = config_pb2.SlicingSpec(
          feature_keys=[ColumnSpec(slices.slice_columns).as_string()])
      slicing_specs.append(slicing_spec)
  return slicing_specs


def _get_model_eval_config_from_service_classification(  # pylint: disable=missing-docstring
    classification: configuration_pb2.ClassificationProblemSpec,
    model_eval_config: model_evaluation_pb2.EvaluationConfig) -> None:
  if classification.HasField('ground_truth_column_spec'):
    model_eval_config.data_spec.label_key_spec.CopyFrom(
        classification.ground_truth_column_spec)
  if classification.HasField('example_weight_column_spec'):
    model_eval_config.data_spec.example_weight_key_spec.CopyFrom(
        classification.example_weight_column_spec)
  if classification.HasField('prediction_score_column_spec'):
    model_eval_config.data_spec.predicted_score_key_spec.CopyFrom(
        classification.prediction_score_column_spec)
  if classification.HasField('prediction_label_column_spec'):
    model_eval_config.data_spec.predicted_label_key_spec.CopyFrom(
        classification.prediction_label_column_spec)
  if classification.HasField('prediction_id_column_spec'):
    model_eval_config.data_spec.predicted_label_id_key_spec.CopyFrom(
        classification.prediction_id_column_spec)
  if classification.evaluation_options.decision_thresholds:
    model_eval_config.data_spec.decision_thresholds.extend(
        classification.evaluation_options.decision_thresholds)
  else:
    model_eval_config.data_spec.decision_thresholds.append(
        Thresholds.DEFAULT_DECISION_THRESHOLD)
  model_eval_config.data_spec.labels.extend(classification.class_names)

  if classification.type == configuration_pb2.ClassificationProblemSpec.MULTICLASS:
    problem_type = constants.ProblemType.MULTICLASS
  elif classification.type == configuration_pb2.ClassificationProblemSpec.MULTILABEL:
    problem_type = constants.ProblemType.MULTILABEL
  else:
    raise UserError('Classification type %r not implemented' %
                    classification.type)

  adapter = tfma_adapter.TFMAToME(
      class_name_list=list(classification.class_names))

  tfma_metric_specs = _get_metric_specs_classification_regression(
      problem_type,
      list(classification.class_names),
      list(classification.evaluation_options.positive_classes),
      list(classification.evaluation_options.top_k_list),
      list(  # pylint: disable=g-long-ternary
          round(num, 3)
          for num in classification.fairness_options.fairness_thresholds)
      if classification.HasField('fairness_options') else None)
  for tfma_metric_spec in tfma_metric_specs:
    model_eval_config.metrics_specs.append(
        adapter.metrics_spec(tfma_metric_spec))
  if classification.slicing_options:
    slices = [
        configuration_pb2.ClassificationProblemSpec.SlicingOptions.Slice(
            slice_columns=(
                classification.slicing_options[0].slices[0].slice_columns))
    ]
    tfma_slices = _get_tfma_slicing_specs(slices)
    # TODO(b/242349026): Implement feature values/cross slicing
    for tfma_slice in tfma_slices:
      model_eval_config.slicing_specs.append(adapter.slicing_spec(tfma_slice))
  # TODO(b/242062793): Need to add slice features in next CL

  if classification.fairness_options.fairness_slices:
    for fair_slices in classification.fairness_options.fairness_slices:
      slicing_spec = model_evaluation_pb2.SlicingSpec(
          feature_key_specs=fair_slices.slices)
      model_eval_config.slicing_specs.append(slicing_spec)


def _get_model_eval_config_from_service_regression(  # pylint: disable=missing-docstring
    regression: configuration_pb2.RegressionProblemSpec,
    model_eval_config: model_evaluation_pb2.EvaluationConfig) -> None:

  if regression.HasField('ground_truth_column_spec'):
    model_eval_config.data_spec.label_key_spec.CopyFrom(
        regression.ground_truth_column_spec)
  if regression.HasField('example_weight_column_spec'):
    model_eval_config.data_spec.example_weight_key_spec.CopyFrom(
        regression.example_weight_column_spec)
  if regression.HasField('prediction_score_column_spec'):
    model_eval_config.data_spec.predicted_score_key_spec.CopyFrom(
        regression.prediction_score_column_spec)

  adapter = tfma_adapter.TFMAToME()

  tfma_metric_specs = _get_metric_specs_classification_regression(
      constants.ProblemType.REGRESSION)
  for tfma_metric_spec in tfma_metric_specs:
    model_eval_config.metrics_specs.append(
        adapter.metrics_spec(tfma_metric_spec))


def _get_model_eval_config_from_service_forecasting(
    forecasting: configuration_pb2.ForecastingProblemSpec,
    model_eval_config: model_evaluation_pb2.EvaluationConfig) -> None:
  """Converts forecasting problem spec to pipeline evaluation config."""
  if forecasting.HasField('ground_truth_column_spec'):
    model_eval_config.data_spec.label_key_spec.CopyFrom(
        forecasting.ground_truth_column_spec)
  if forecasting.HasField('example_weight_column_spec'):
    model_eval_config.data_spec.example_weight_key_spec.CopyFrom(
        forecasting.example_weight_column_spec)
  if forecasting.HasField('prediction_score_column_spec'):
    model_eval_config.data_spec.predicted_score_key_spec.CopyFrom(
        forecasting.prediction_score_column_spec)

  if forecasting.type == configuration_pb2.ForecastingProblemSpec.POINT:
    adapter = tfma_adapter.TFMAToME()
    tfma_metric_specs = tfma_metrics.get_metric_specs(
        metric_names=list(POINT_FORECASTING_METRICS), is_multi_label=False)
  elif forecasting.type == configuration_pb2.ForecastingProblemSpec.QUANTILE:
    adapter = tfma_adapter.TFMAToME()
    model_eval_config.data_spec.quantiles.extend(forecasting.quantiles)
    custom_metric_map = {
        Metric.QUANTILE_ACCURACY:
            tfma_metrics.MetricSpec(
                class_name='QuantileAccuracy',
                module_name=quantile_accuracy.__name__,
                config={
                    'name': Metric.QUANTILE_ACCURACY,
                    'quantiles': list(forecasting.quantiles)
                },
                aggregatable=False)
    }
    if forecasting.options.enable_point_evaluation:
      model_eval_config.data_spec.quantile_index = forecasting.options.point_evaluation_quantile_index
      tfma_metric_specs = tfma_metrics.get_metric_specs(
          metric_names=list(POINT_FORECASTING_METRICS),
          model_names=[
              constants.Pipeline.MODEL_KEY + constants.Data.POINT_KEY_SUFFIX
          ],
          is_multi_label=False)
      tfma_metric_specs.extend(
          tfma_metrics.get_metric_specs(
              metric_names=list(QUANTILE_FORECASTING_METRICS),
              model_names=[
                  constants.Pipeline.MODEL_KEY +
                  constants.Data.QUANTILE_KEY_SUFFIX
              ],
              is_multi_label=False,
              custom_metric_map=custom_metric_map))
    else:
      model_eval_config.data_spec.quantile_index = -1
      tfma_metric_specs = tfma_metrics.get_metric_specs(
          metric_names=list(QUANTILE_FORECASTING_METRICS),
          is_multi_label=False,
          custom_metric_map=custom_metric_map)
  else:
    raise NotImplementedError('Forecasting type %r not implemented' %
                              forecasting.type)

  for tfma_metric_spec in tfma_metric_specs:
    model_eval_config.metrics_specs.append(
        adapter.metrics_spec(tfma_metric_spec))


def _is_field_present(msg: message.Message,
                      field_name: str,
                      error_msgs: List[str],
                      error_prefix: str = '') -> bool:
  """Checks whether a message field in a proto is present."""
  if not msg.HasField(field_name):
    error_msgs.append('{}{} field is missing'.format(error_prefix, field_name))
    return False
  return True


def _verify_field_specified(msg: message.Message,
                            field_name: str,
                            error_msgs: List[str],
                            error_prefix: Optional[str] = '') -> None:
  """Verifies that a field in a proto is specified."""
  if not getattr(msg, field_name):
    error_msgs.append('{}{} is not specified'.format(error_prefix, field_name))


def _validate_service_config_data_source(
    data_source: configuration_pb2.DataSource, error_msgs: List[str]) -> None:
  """Validates data_source specification within service configuration."""
  if not _is_field_present(data_source, 'source', error_msgs):
    return
  if data_source.HasField('gcs_source'):
    # Verify legacy gcs source input.
    gcs_source = data_source.gcs_source
    _verify_field_specified(
        msg=gcs_source,
        field_name='files',
        error_msgs=error_msgs,
        error_prefix='gcs_source: ')
    _verify_field_specified(
        msg=gcs_source,
        field_name='format',
        error_msgs=error_msgs,
        error_prefix='gcs_source: ')
  elif data_source.HasField('single_source'):
    # Verify non-joining source input.
    if data_source.single_source.HasField('gcs_source'):
      gcs_source = data_source.single_source.gcs_source
      _verify_field_specified(
          msg=gcs_source,
          field_name='files',
          error_msgs=error_msgs,
          error_prefix='source.gcs_source: ')
      _verify_field_specified(
          msg=gcs_source,
          field_name='format',
          error_msgs=error_msgs,
          error_prefix='source.gcs_source: ')
    elif data_source.single_source.HasField('bigquery_source'):
      bigquery_source = data_source.single_source.bigquery_source
      _verify_field_specified(
          msg=bigquery_source,
          field_name='uri',
          error_msgs=error_msgs,
          error_prefix='source.bigquery_source: ')
    else:
      error_msgs.append(
          'unrecognized data_source.single_source field, '
          'expecting gcs_source or bigquery_source, '
          f'seeing {data_source.single_source.WhichOneof("source_type")}')
  elif data_source.HasField('joining_source'):
    joining_source = data_source.joining_source
    # Verify the prediction data input.
    _verify_field_specified(
        msg=joining_source,
        field_name='prediction_data',
        error_msgs=error_msgs,
        error_prefix='joining_source: ')
    prediction_data = joining_source.prediction_data
    if prediction_data.HasField('gcs_source'):
      _verify_field_specified(
          msg=prediction_data.gcs_source,
          field_name='files',
          error_msgs=error_msgs,
          error_prefix='joining_source.prediction_data.gcs_source: ')
      _verify_field_specified(
          msg=prediction_data.gcs_source,
          field_name='format',
          error_msgs=error_msgs,
          error_prefix='joining_source.prediction_data.gcs_source: ')
      if prediction_data.gcs_source.format != configuration_pb2.DataSource.GcsSource.JSONL:
        error_msgs.append(
            'Unsupported data_source.joining_source.prediction_data.gcs_source'
            f'.format: {prediction_data.gcs_source.format}')
    elif prediction_data.HasField('bigquery_source'):
      _verify_field_specified(
          msg=prediction_data.bigquery_source,
          field_name='uri',
          error_msgs=error_msgs,
          error_prefix='joining_source.prediction_data.bigquery_source: ')
    else:
      error_msgs.append(
          'unrecognized data_source.joining_source.prediction_data field, '
          'expecting gcs_source or bigquery_source, '
          f'seeing {prediction_data.WhichOneof("source_type")}')
    # Verify the ground truth data input.
    _verify_field_specified(
        msg=joining_source,
        field_name='ground_truth_data',
        error_msgs=error_msgs,
        error_prefix='joining_source: ')
    ground_truth_data = joining_source.ground_truth_data
    if ground_truth_data.HasField('gcs_source'):
      _verify_field_specified(
          msg=ground_truth_data.gcs_source,
          field_name='files',
          error_msgs=error_msgs,
          error_prefix='joining_source.ground_truth_data.gcs_source: ')
      _verify_field_specified(
          msg=ground_truth_data.gcs_source,
          field_name='format',
          error_msgs=error_msgs,
          error_prefix='joining_source.ground_truth_data.gcs_source: ')
      if (ground_truth_data.gcs_source.format not in [
          configuration_pb2.DataSource.GcsSource.JSONL,
          configuration_pb2.DataSource.GcsSource.CSV
      ]):
        error_msgs.append('Unsupported data_source.joining_source.'
                          'ground_truth_data.gcs_source.'
                          f'format: {ground_truth_data.gcs_source.format}')
    elif ground_truth_data.HasField('bigquery_source'):
      _verify_field_specified(
          msg=ground_truth_data.bigquery_source,
          field_name='uri',
          error_msgs=error_msgs,
          error_prefix='joining_source.ground_truth_data.bigquery_source: ')
    else:
      error_msgs.append(
          'unrecognized data_source.joining_source.ground_truth_data field, '
          'expecting gcs_source or bigquery_source, '
          f'seeing {ground_truth_data.WhichOneof("source_type")}')
    # Verify the key columns.
    _verify_field_specified(
        msg=joining_source,
        field_name='key_columns',
        error_msgs=error_msgs,
        error_prefix='joining_source: ')
  else:
    error_msgs.append(
        'unrecognized data_source field, expecting source '
        f'or joining_source, seeing {data_source.WhichOneof("source")}')


def _validate_service_config_problem(problem: configuration_pb2.ProblemSpec,
                                     error_msgs: List[str]) -> None:
  """Validates problem specification within service configuration."""
  problem_kind = problem.WhichOneof('problems')
  if problem_kind is None:
    error_msgs.append('problem type is not specified.')
    return

  if problem_kind == 'classification':
    classification = problem.classification
    if not classification.class_names:
      error_msgs.append(
          'classification: class_names must be specified and non-empty.')

    if _is_field_present(classification, 'ground_truth_column_spec', error_msgs,
                         'classification: '):
      _verify_field_specified(
          msg=classification.ground_truth_column_spec,
          field_name='name',
          error_msgs=error_msgs,
          error_prefix='classification.ground_truth_column_spec: ')

    if _is_field_present(classification, 'prediction_score_column_spec',
                         error_msgs, 'classification: '):
      _verify_field_specified(
          msg=classification.prediction_score_column_spec,
          field_name='name',
          error_msgs=error_msgs,
          error_prefix='classification.prediction_score_column_spec: ')
    if classification.type == configuration_pb2.ClassificationProblemSpec.UNKNOWN:
      error_msgs.append('classification: type must be specified.')
    return

  if problem_kind == 'regression':
    regression = problem.regression
    if _is_field_present(regression, 'ground_truth_column_spec', error_msgs,
                         'regression: '):
      _verify_field_specified(
          msg=regression.ground_truth_column_spec,
          field_name='name',
          error_msgs=error_msgs,
          error_prefix='regression.ground_truth_column_spec: ')

    if _is_field_present(regression, 'prediction_score_column_spec', error_msgs,
                         'regression: '):
      _verify_field_specified(
          msg=regression.prediction_score_column_spec,
          field_name='name',
          error_msgs=error_msgs,
          error_prefix='regression.prediction_score_column_spec: ')
    return

  if problem_kind == 'forecasting':
    forecasting = problem.forecasting
    if _is_field_present(forecasting, 'ground_truth_column_spec', error_msgs,
                         'forecasting: '):
      _verify_field_specified(
          msg=forecasting.ground_truth_column_spec,
          field_name='name',
          error_msgs=error_msgs,
          error_prefix='forecasting.ground_truth_column_spec: ')

    if _is_field_present(forecasting, 'prediction_score_column_spec',
                         error_msgs, 'forecasting: '):
      _verify_field_specified(
          msg=forecasting.prediction_score_column_spec,
          field_name='name',
          error_msgs=error_msgs,
          error_prefix='forecasting.prediction_score_column_spec: ')

    if forecasting.type == configuration_pb2.ForecastingProblemSpec.UNKNOWN:
      error_msgs.append('forecasting: type must be specified.')

    if forecasting.type == configuration_pb2.ForecastingProblemSpec.QUANTILE:
      if not forecasting.quantiles:
        error_msgs.append(
            'quantile forecasting: quantiles must be specified and non-empty.')
      if not all((v >= 0 and v <= 1) for v in forecasting.quantiles):
        raise TypeError(
            '{}: all values are expected to be between 0 and 1 but are not.'
            .format(forecasting.quantiles))
      if forecasting.HasField(
          'options') and forecasting.options.enable_point_evaluation:
        index = forecasting.options.point_evaluation_quantile_index
        if index < 0 or index >= len(forecasting.quantiles):
          error_msgs.append('quantile forecasting: invalid quantile index.')


def _validate_service_config_output(output: configuration_pb2.OutputSpec,
                                    error_msgs: List[str]) -> None:
  """Validates output specification within service configuration."""
  if not _is_field_present(output, 'gcs_sink', error_msgs):
    return
  # TODO(kevinbnaughton): Add validation for oneof field.


def _validate_service_config_execution(
    execution: configuration_pb2.ExecutionSpec, error_msgs: List[str]) -> None:
  """Validates execution specification within service configuration."""
  execution_kind = execution.WhichOneof('spec')
  if execution_kind is None:
    error_msgs.append('execution spec is missing.')
    return

  if execution_kind == 'dataflow_beam':
    dataflow_beam = execution.dataflow_beam
    _verify_field_specified(
        msg=dataflow_beam,
        field_name='dataflow_job_prefix',
        error_msgs=error_msgs,
        error_prefix='dataflow_beam: ')
    _verify_field_specified(
        msg=dataflow_beam,
        field_name='project_id',
        error_msgs=error_msgs,
        error_prefix='dataflow_beam: ')
    _verify_field_specified(
        msg=dataflow_beam,
        field_name='dataflow_staging_dir',
        error_msgs=error_msgs,
        error_prefix='dataflow_beam: ')
    _verify_field_specified(
        msg=dataflow_beam,
        field_name='dataflow_temp_dir',
        error_msgs=error_msgs,
        error_prefix='dataflow_beam: ')
    _verify_field_specified(
        msg=dataflow_beam,
        field_name='region',
        error_msgs=error_msgs,
        error_prefix='dataflow_beam: ')


def validate_service_config(
    eval_service_config: configuration_pb2.EvaluationRunConfig) -> None:
  """Validates model evaluation service config.

  Args:
    eval_service_config: A Model Evaluation Service configuration.

  Raises:
    ValueError if eval_service_config is invalid.
  """
  error_msgs = []
  if not eval_service_config.name:
    error_msgs.append('name is not specified.')

  if _is_field_present(eval_service_config, 'data_source', error_msgs):
    _validate_service_config_data_source(eval_service_config.data_source,
                                         error_msgs)

  if _is_field_present(eval_service_config, 'problem', error_msgs):
    _validate_service_config_problem(eval_service_config.problem, error_msgs)

  if _is_field_present(eval_service_config, 'output', error_msgs):
    _validate_service_config_output(eval_service_config.output, error_msgs)

  if _is_field_present(eval_service_config, 'execution', error_msgs):
    _validate_service_config_execution(eval_service_config.execution,
                                       error_msgs)

  if error_msgs:
    error_msgs_str = '\n  *'.join(error_msgs)
    raise ValueError(
        'Model Evaluation Service configuration for backend ' +
        f'{eval_service_config} has following errors: {error_msgs_str}')


def validate_preprocessing_config(
    preprocessing_config: preprocessing_pb2.PreprocessingRunConfig) -> None:
  """Validates preprocessing component config.

  Args:
    preprocessing_config: A preprocessing component service configuration.

  Raises:
    ValueError if preprocessing_config is invalid.
  """
  error_msgs = []
  if not preprocessing_config.name:
    error_msgs.append('name is not specified.')

  if _is_field_present(preprocessing_config, 'data_source', error_msgs):
    _validate_service_config_data_source(preprocessing_config.data_source,
                                         error_msgs)

  if _is_field_present(preprocessing_config, 'output', error_msgs):
    _validate_service_config_output(preprocessing_config.output, error_msgs)

  if _is_field_present(preprocessing_config, 'execution', error_msgs):
    _validate_service_config_execution(preprocessing_config.execution,
                                       error_msgs)

  if error_msgs:
    error_msgs_str = '\n  *'.join(error_msgs)
    raise ValueError(
        'Preprocessing Component configuration for backend ' +
        f'{preprocessing_config} has following errors: {error_msgs_str}')


def get_model_evaluation_config_from_service_config(
    eval_service_config: configuration_pb2.EvaluationRunConfig
) -> model_evaluation_pb2.EvaluationConfig:
  """Converts Model Evaluation Service into CAIMQ Evaluation Config."""
  if not eval_service_config:
    return None

  model_eval_config = model_evaluation_pb2.EvaluationConfig()
  model_eval_config.name = eval_service_config.name
  model_eval_config.data_spec.input_source_spec.CopyFrom(
      eval_service_config.data_source)

  model_eval_config.output_spec.CopyFrom(eval_service_config.output)

  if eval_service_config.problem.HasField('classification'):
    _get_model_eval_config_from_service_classification(
        eval_service_config.problem.classification, model_eval_config)
  elif eval_service_config.problem.HasField('regression'):
    _get_model_eval_config_from_service_regression(
        eval_service_config.problem.regression, model_eval_config)
  elif eval_service_config.problem.HasField('forecasting'):
    _get_model_eval_config_from_service_forecasting(
        eval_service_config.problem.forecasting, model_eval_config)
  else:
    raise NotImplementedError('Problem %r not implemented' %
                              eval_service_config.problem)

  model_eval_config.execution_spec.CopyFrom(eval_service_config.execution)

  return model_eval_config


def _get_dataflow_job_name(dataflow_job_prefix, task_run_name):
  return '{}-{}'.format(dataflow_job_prefix, task_run_name)


def get_pipeline_options_from_service_config(
    task_run_name: str, task_execution_spec: configuration_pb2.ExecutionSpec
) -> pipeline_opts_lib.PipelineOptions:
  """Specifies Beam pipeline options based on task service config."""
  pipeline_options = pipeline_opts_lib.PipelineOptions()
  if task_execution_spec.HasField('dataflow_beam'):
    dataflow_beam_spec = task_execution_spec.dataflow_beam
    google_cloud_options = pipeline_options.view_as(
        pipeline_opts_lib.GoogleCloudOptions)
    google_cloud_options.project = dataflow_beam_spec.project_id
    if dataflow_beam_spec.service_account:
      google_cloud_options.service_account_email = dataflow_beam_spec.service_account
    if dataflow_beam_spec.kms_key_name:
      google_cloud_options.dataflow_kms_key = dataflow_beam_spec.kms_key_name
    google_cloud_options.region = dataflow_beam_spec.region
    google_cloud_options.job_name = _get_dataflow_job_name(
        dataflow_beam_spec.dataflow_job_prefix, task_run_name)
    google_cloud_options.staging_location = dataflow_beam_spec.dataflow_staging_dir
    google_cloud_options.temp_location = dataflow_beam_spec.dataflow_temp_dir
    google_cloud_options.dataflow_service_options = ['use_runner_v2']

    debug_options = pipeline_options.view_as(pipeline_opts_lib.DebugOptions)
    debug_options.experiments = ['use_runner_v2']

    worker_options = pipeline_options.view_as(pipeline_opts_lib.WorkerOptions)
    if dataflow_beam_spec.num_workers:
      worker_options.num_workers = dataflow_beam_spec.num_workers
    if dataflow_beam_spec.max_num_workers:
      worker_options.max_num_workers = dataflow_beam_spec.max_num_workers
    if dataflow_beam_spec.machine_type:
      worker_options.machine_type = dataflow_beam_spec.machine_type
    if dataflow_beam_spec.disk_size_gb:
      worker_options.disk_size_gb = dataflow_beam_spec.disk_size_gb

    if dataflow_beam_spec.HasField('subnetwork'):
      worker_options.subnetwork = dataflow_beam_spec.subnetwork.name
      worker_options.use_public_ips = dataflow_beam_spec.subnetwork.use_public_ips
    else:
      worker_options.use_public_ips = True

    setup_options = pipeline_options.view_as(pipeline_opts_lib.SetupOptions)
    setup_options.setup_file = dataflow_beam_spec.setup_file or ENV_SETUP_FILE or './setup.py'
    setup_options.sdk_location = 'container'
    # TODO(kevinbnaughton): Come to consensus about having default image in:
    # https://pantheon.corp.google.com/artifacts/browse/vertex-ai?project=vertex-ai&mods=-ai_platform_fake_service
    if dataflow_beam_spec.worker_container_image:
      worker_options.sdk_container_image = dataflow_beam_spec.worker_container_image
    else:
      # Provide default worker container image.
      worker_options.sdk_container_image = constants.Pipeline.WORKER_CONTAINER_IMAGE

    pipeline_options.view_as(pipeline_opts_lib.StandardOptions
                            ).runner = constants.Pipeline.DATAFLOW_RUNNER
  else:
    local_beam_spec = task_execution_spec.local_beam
    pipeline_options.view_as(pipeline_opts_lib.DirectOptions
                            ).direct_num_workers = local_beam_spec.num_workers
  return pipeline_options


def get_problem_type_from_service_config(
    eval_service_config: configuration_pb2.EvaluationRunConfig
) -> constants.ProblemType:
  """Gets evaluation problem type from model evaluation service config.

  Args:
    eval_service_config: Model evaluation service config.

  Returns:
    Type of the model evaluation problem.

  Raises:
    ValueError if the specified evaluation problem type is invalid.
  """
  if eval_service_config.problem.HasField('regression'):
    return constants.ProblemType.REGRESSION

  if eval_service_config.problem.HasField('classification'):
    classification = eval_service_config.problem.classification
    if classification.type == configuration_pb2.ClassificationProblemSpec.MULTICLASS:
      return constants.ProblemType.MULTICLASS
    if classification.type == configuration_pb2.ClassificationProblemSpec.MULTILABEL:
      return constants.ProblemType.MULTILABEL

    raise ValueError('Unsupported classification problem type: {}'.format(
        classification.type))

  if eval_service_config.problem.HasField('forecasting'):
    forecasting = eval_service_config.problem.forecasting
    if forecasting.type == configuration_pb2.ForecastingProblemSpec.POINT:
      return constants.ProblemType.POINT_FORECASTING
    if forecasting.type == configuration_pb2.ForecastingProblemSpec.QUANTILE:
      return constants.ProblemType.QUANTILE_FORECASTING

    raise ValueError('Unsupported forecasting problem type: {}'.format(
        forecasting.type))

  raise ValueError('Evaluation problem type either unspecified or unsupported '
                   'in the configuration \n {}'.format(eval_service_config))
