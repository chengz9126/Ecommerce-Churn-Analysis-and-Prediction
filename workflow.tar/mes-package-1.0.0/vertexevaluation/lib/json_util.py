"""Json utility module."""
from typing import Dict, Any

_FLATTEN_JSON_SEPARATOR = "."


def flatten_dict(json_dict: Dict[str, Any],
                 sep: str = _FLATTEN_JSON_SEPARATOR) -> Dict[str, Any]:
  """Recursively flattens dictionary.

  For example,
  {"a": {"b": "c"}} -> {"a.b": "c"}

  {"a": ["b", "c"]} -> {"a.0": "b", "a.1": "c"}

  Args:
    json_dict: dictionary to be flattened.
    sep: Separator, default to be "."

  Returns:
    Flattened dictionary.
  """
  flattened_dict = {}

  def _flatten_json(input_object: Any, name: str = "") -> None:
    if isinstance(input_object, dict):
      for key, val in input_object.items():
        _flatten_json(val, f"{name}{key}{sep}")
    elif isinstance(input_object, (list, tuple, set)):
      for idx, val in enumerate(input_object):
        _flatten_json(val, f"{name}{idx}{sep}")
    else:
      flattened_dict[name[:-1]] = input_object

  _flatten_json(json_dict)
  return flattened_dict
