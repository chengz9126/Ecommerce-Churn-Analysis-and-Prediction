"""Module to retrieve Vertex AI model details."""
from typing import Tuple

from absl import app
from google.api_core.client_options import ClientOptions
from google.api_core.exceptions import NotFound
from google.cloud.aiplatform_v1.services.model_service.client import ModelServiceClient
from google.cloud.aiplatform_v1.types.model import ModelSourceInfo
from google.cloud.aiplatform_v1.types.model_service import GetModelRequest


def get_vertex_model_source_type(
    model_resource_name: str) -> ModelSourceInfo.ModelSourceType:
  """Get Vertex AI model source type.

  Args:
    model_resource_name: a string of Vertex AI model resource name. E.g.
      "projects/{project_id}/locations/{location}/models/{model_id}"

  Returns:
    ModelSourceInfo.ModelSourceType
  """
  if not model_resource_name:
    return ModelSourceInfo.ModelSourceType(
        ModelSourceInfo.ModelSourceType
        .MODEL_SOURCE_TYPE_UNSPECIFIED)

  _, location, _ = verify_vertex_model_resource_name(model_resource_name)
  client_options = ClientOptions(
      api_endpoint=f'{location}-aiplatform.googleapis.com:443')
  client = ModelServiceClient(client_options=client_options)
  request = GetModelRequest(name=model_resource_name)
  try:
    return client.get_model(request).model_source_info.source_type
  except NotFound as e:
    raise app.UsageError(
        'Model {} not found'.format(model_resource_name)) from e


def verify_vertex_model_resource_name(
    model_resource_name: str) -> Tuple[str, str, str]:
  """Verify model resource name and return project, location, model_id.

  Args:
    model_resource_name: a string of Vertex AI model resource name. E.g.
      "projects/{project_id}/locations/{location}/models/{model_id}"

  Returns:
    A tuple of project_id, location and model_id

  Raises:
    UsageError: error occuring if resource name is invalid.
  """
  splitted_source_name = model_resource_name.split('/')
  if (len(splitted_source_name) != 6 or
      splitted_source_name[0] != 'projects' or
      splitted_source_name[2] != 'locations' or
      splitted_source_name[4] != 'models'):
    raise app.UsageError(
        'Invalid model name: {}, expecting projects/{{project_id}}/locations/{{location}}/models/{{model_id}}'
        .format(model_resource_name))
  return splitted_source_name[1], splitted_source_name[
      3], splitted_source_name[5]
