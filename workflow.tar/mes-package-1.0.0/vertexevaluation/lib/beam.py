"""Beam-specific functionality for Cloud AI Evluation Metrics."""

import json
import os.path
from typing import Any, Iterable, List, Optional
from typing import Union

from absl import logging
import apache_beam as beam
from apache_beam.io.gcp.internal.clients import bigquery
import tensorflow_model_analysis as tfma
from tensorflow_model_analysis.proto import metrics_for_slice_pb2
from tfx_bsl.tfxio import tensor_adapter
from tfx_bsl.tfxio import tf_example_record
from vertexevaluation.error import error
from vertexevaluation.lib import bigquery_lib
from vertexevaluation.lib import column_spec
from vertexevaluation.lib import constants
from vertexevaluation.lib import csv_lib
from vertexevaluation.lib import csv_to_jsonl
from vertexevaluation.lib import evaluation_column_specs as ecs
from vertexevaluation.lib import io
from vertexevaluation.lib import joiner_lib
from vertexevaluation.lib import tfma_adapter
from vertexevaluation.lib.explanation_lib import aggregate_feature_attribution
from vertexevaluation.proto import configuration_pb2
from vertexevaluation.proto import model_evaluation_pb2 as me_proto

from google.protobuf import json_format
from google.protobuf import message

ColumnSpec = column_spec.ColumnSpec
EvaluationColumnSpecs = ecs.EvaluationColumnSpecs
UserError = error.UserError


class JSONToSerializedExample(beam.DoFn):
  """Deserialize JSON data and return serialized tf.Example."""

  def __init__(self,
               eval_column_specs: EvaluationColumnSpecs,
               class_list: Optional[List[str]] = None,
               quantile_list: Optional[List[float]] = None,
               quantile_index: Optional[int] = None):
    """Construct a transformation.

    Args:
      eval_column_specs: The set of specs for columns needed for model
        evaluation.
      class_list: For classification task, a list of class names.
      quantile_list: For quantile forecasting task, a list of quantiles.
      quantile_index: For quantile forecasting task, the quantile index.
    """
    self._eval_column_specs = eval_column_specs
    self.class_list = class_list
    self.quantile_list = quantile_list
    self.quantile_index = quantile_index

  def process(self, input_data: Union[bytes, str]) -> Iterable[bytes]:
    """Convert a single row of data.

    Args:
      input_data: A JSON serialized dict of features, labels, and predictions.

    Yields:
      a tensorflow.Example serialized as bytes.
    """
    try:
      tf_example = io.parse_row_as_example(
          json_data=input_data,
          evaluation_column_specs=self._eval_column_specs,
          class_list=self.class_list,
          quantile_list=self.quantile_list,
          quantile_index=self.quantile_index)
      yield tf_example.SerializeToString()
    except ValueError as e:
      yield beam.pvalue.TaggedOutput(
          'errors',
          ('Not able to parse row as an example, error: [%s]', str(e)))


_TFMA_METRICS_KEY = 'metrics'


def _proto_as_json(msg: message.Message) -> str:
  return json_format.MessageToJson(msg, indent=0).replace('\n', '')


def _bq_as_json(bq_row_dict) -> str:
  # TODO(b/246852232) If BP team fixes this bug, remove this check for custom
  # models.
  if isinstance(bq_row_dict,
                dict) and 'prediction' in bq_row_dict and isinstance(
                    bq_row_dict['prediction'], str):
    bq_row_dict['prediction'] = json.loads(bq_row_dict['prediction'])
  return json.dumps(bq_row_dict, default=str)


class MakeSliceMetricsSet(beam.CombineFn):
  """A Combiner that groups a list of SliceMetricsSet into a SlicedMetricSet."""

  def create_accumulator(self):
    return me_proto.SlicedMetricsSet()

  def add_input(self, accumulator, value):
    accumulator.sliced_metrics.extend(value.sliced_metrics)
    return accumulator

  def merge_accumulators(self, accumulators):
    result = me_proto.SlicedMetricsSet()
    for accumulator in accumulators:
      result.sliced_metrics.extend(accumulator.sliced_metrics)
    return result

  def extract_output(self, accumulator):
    return accumulator


@beam.ptransform_fn
# TODO(b/148788775): These type hints fail Beam type checking. Failing test:
# evaluation/metrics/lib:beam_test
# @beam.typehints.with_input_types(tfma.evaluators.Evaluation)
def _write_metrics(evaluation: tfma.evaluators.Evaluation,
                   output_file: str,
                   problem_type: constants.ProblemType,
                   class_labels: Optional[List[str]] = None,
                   tfma_format: Optional[bool] = False,
                   json_mode: Optional[bool] = False):
  """PTransform to write metrics in different formats."""

  def _convert_metrics(tfma_metrics):
    return tfma_adapter.TFMAToME.model_evaluation_metrics(
        tfma_metrics, problem_type, class_labels)

  extract = (
      evaluation[_TFMA_METRICS_KEY] | 'ConvertSliceMetricsToProto' >> beam.Map(
          tfma.writers.metrics_plots_and_validations_writer
          .convert_slice_metrics_to_proto,
          add_metrics_callbacks=[]))

  if tfma_format:
    metrics = extract
  else:
    metrics = (
        extract | 'TFMAMetricsToME' >> beam.Map(_convert_metrics)
        | 'Combine' >> beam.CombineGlobally(MakeSliceMetricsSet()))

  if json_mode:
    _ = (
        metrics | 'ToJSON' >> beam.Map(_proto_as_json)
        | 'WriteToText' >> beam.io.WriteToText(
            file_path_prefix=output_file,
            shard_name_template='',
            file_name_suffix=''))
  elif tfma_format:
    _ = (
        metrics | 'WriteToTFRecord' >> beam.io.WriteToTFRecord(
            file_path_prefix=output_file,
            shard_name_template='',
            file_name_suffix='',
            coder=beam.coders.ProtoCoder(metrics_for_slice_pb2.MetricsForSlice))
    )
  else:
    _ = (
        metrics | 'Write' >> beam.io.WriteToText(
            file_path_prefix=output_file,
            shard_name_template='',
            file_name_suffix='',
            append_trailing_newlines=False,
            compression_type='uncompressed',
            coder=beam.coders.ProtoCoder(me_proto.SlicedMetricsSet)))


def append_tfma_pipeline(pipeline: beam.Pipeline,
                         model_eval_config: me_proto.EvaluationConfig,
                         problem_type: constants.ProblemType,
                         tfma_format: Optional[bool] = False,
                         json_mode: Optional[bool] = False,
                         schema: Optional[Any] = None) -> beam.Pipeline:
  """Extend a beam pipeline to add TFMA evaluation given a configuration.

  Args:
    pipeline: A beam pipeline.
    model_eval_config: A Model Evaluation Configuration from
      model_evaluation_pb2.
    problem_type: Defines what type of problem to expect.
    tfma_format: If true, use TFMA format, if false use Model Evaluation.
    json_mode: Output metrics in a plain text mode.
    schema: Optional tf.metadata schema. If you need to pass multi-tensor input
      to the model, you need to pass the schema.

  Returns:
    The beam pipeline.
  """
  coder = tf_example_record.TFExampleBeamRecord(
      physical_format='inmem',
      schema=schema,
      raw_record_column_name=tfma.ARROW_INPUT_COLUMN,
      telemetry_descriptors=None)

  data_spec = model_eval_config.data_spec
  class_name_list = list(model_eval_config.data_spec.labels) or None
  merged_dataset = read_and_merge_data(pipeline, data_spec.input_source_spec,
                                       problem_type)
  if model_eval_config.output_spec.gcs_sink.HasField('path'):
    output_file = os.path.join(model_eval_config.output_spec.gcs_sink.path,
                               constants.Pipeline.METRICS_KEY)
  else:
    output_file = model_eval_config.output_spec.gcs_sink.uri

  eval_config = tfma_adapter.METoTFMA(class_name_list).eval_config(
      model_eval_config)

  writers = [
      tfma.writers.Writer(
          stage_name='WriteMetrics',
          # pylint:disable=no-value-for-parameter
          ptransform=_write_metrics(
              output_file=output_file,
              problem_type=problem_type,
              class_labels=class_name_list,
              tfma_format=tfma_format,
              json_mode=json_mode))
  ]

  has_fairness_metrics = False

  for metric_spec in model_eval_config.metrics_specs:
    for metric in metric_spec.metrics:
      if metric.name == 'FairnessIndicators':
        has_fairness_metrics = True
        break
    else:
      continue
    break

  if has_fairness_metrics:
    # TODO(b/242233677) Create output_path for Fairness Indicators to
    # be used on Fairness Indicator Widget. Using output_file as path
    # because creating a new directory causes a Build error. The
    # directory created is write-protected and the files inside cannot
    # be deleted.
    fairness_output_file_path = os.path.dirname(output_file)

    writers.append(
        tfma.writers.EvalConfigWriter(
            output_path=fairness_output_file_path,
            eval_config=eval_config,
        ))

    output_paths = {
        constants.OutputKey.METRICS_KEY:
            os.path.join(fairness_output_file_path,
                         constants.OutputKey.METRICS_KEY),
        constants.OutputKey.PLOTS_KEY:
            os.path.join(fairness_output_file_path,
                         constants.OutputKey.PLOTS_KEY),
        constants.OutputKey.ATTRIBUTIONS_KEY:
            os.path.join(fairness_output_file_path,
                         constants.OutputKey.ATTRIBUTIONS_KEY),
        constants.OutputKey.VALIDATIONS_KEY:
            os.path.join(fairness_output_file_path,
                         constants.OutputKey.VALIDATIONS_KEY)
    }

    writers.append(
        tfma.writers.MetricsPlotsAndValidationsWriter(
            output_paths=output_paths, eval_config=eval_config))

  if schema is None:
    tensor_adapter_config = None
  else:
    tensor_adapter_config = tensor_adapter.TensorAdapterConfig(
        arrow_schema=coder.ArrowSchema(),
        tensor_representations=coder.TensorRepresentations())
  _ = (
      merged_dataset
      | 'ParseData' >> beam.ParDo(
          JSONToSerializedExample(
              eval_column_specs=EvaluationColumnSpecs(
                  ground_truth_column_spec=ColumnSpec(data_spec.label_key_spec),
                  example_weight_column_spec=ColumnSpec(
                      data_spec.example_weight_key_spec)
                  if data_spec.HasField('example_weight_key_spec') else None,
                  predicted_score_column_spec=ColumnSpec(
                      data_spec.predicted_score_key_spec)
                  if data_spec.HasField('predicted_score_key_spec') else None,
                  predicted_label_column_spec=ColumnSpec(
                      data_spec.predicted_label_key_spec)
                  if data_spec.HasField('predicted_label_key_spec') else None,
                  predicted_label_id_column_spec=ColumnSpec(
                      data_spec.predicted_label_id_key_spec) if
                  data_spec.HasField('predicted_label_id_key_spec') else None),
              class_list=class_name_list,
              quantile_list=list(data_spec.quantiles) or None,
              quantile_index=data_spec.quantile_index
              if data_spec.quantile_index >= 0 else None,
          ))
      | 'ExamplesToRecordBatch' >> coder.BeamSource()
      | 'ExtractEvaluateAndWriteResults' >> tfma.ExtractEvaluateAndWriteResults(
          eval_config=eval_config,
          writers=writers,
          tensor_adapter_config=tensor_adapter_config))

  explanation_path = model_eval_config.output_spec.explanation_gcs_path
  if explanation_path:
    aggregate_feature_attribution(merged_dataset, explanation_path)
  return pipeline


def read_and_merge_data(pipeline, input_source_spec, problem_type=None):
  """Reads data and joins if necessary.

  Args:
    pipeline: The beam pipeline for reading the data.
    input_source_spec: A DataSource message containing the configuration for
      where the data lies and whether to join.
    problem_type: Type of ML problem for which the data is for.

  Returns:
    PCollection containing the loaded data
  """

  def read_from_gcs(gcs_source):
    files = pipeline | 'InputFileList' >> beam.Create(gcs_source.files)
    if gcs_source.format == configuration_pb2.DataSource.GcsSource.JSONL:
      return files | 'ReadText' >> beam.io.textio.ReadAllFromText()
    elif gcs_source.format == configuration_pb2.DataSource.GcsSource.CSV:
      if not problem_type:
        raise UserError('Need to specify problem_type for CSV')
      return (files
              |
              'ReadText' >> beam.io.textio.ReadAllFromText(skip_header_lines=1)
              | 'ConvertToJsonl' >> beam.ParDo(
                  csv_to_jsonl.CsvToJsonl(
                      csv_to_jsonl.get_headers_from_file(gcs_source.files[0]),
                      problem_type)))
    else:
      raise UserError(f'Unsupported GCS data format: {gcs_source.format}')

  def read_from_bigquery(table_uri: str, table_type: str = 'prediction'):
    project_id, dataset_id, table_id = bigquery_lib.parse_bigquery_uri(
        table_uri)
    table_spec = bigquery.TableReference(
        projectId=project_id, datasetId=dataset_id, tableId=table_id)
    return (
        pipeline
        |
        f'ReadTable_{table_type}' >> beam.io.ReadFromBigQuery(table=table_spec)
        | f'DumpJson_{table_type}' >> beam.Map(_bq_as_json))

  # Use legacy non-joining gcs source.
  if input_source_spec.HasField('gcs_source'):
    return read_from_gcs(input_source_spec.gcs_source)

  # Not use joining source.
  if input_source_spec.HasField('single_source'):
    if input_source_spec.single_source.HasField('gcs_source'):
      return read_from_gcs(input_source_spec.single_source.gcs_source)
    return read_from_bigquery(
        input_source_spec.single_source.bigquery_source.uri)

  # Use joining source.
  joining_data = input_source_spec.joining_source

  if joining_data.HasField('key_prefix_in_prediction_dataset'):
    key_prefix_in_prediction_dataset = ColumnSpec(
        joining_data.key_prefix_in_prediction_dataset).as_string()
  else:
    key_prefix_in_prediction_dataset = ''
  if joining_data.key_columns:
    key_columns = list([
        ColumnSpec(key_column).as_string()
        for key_column in joining_data.key_columns
    ])
  else:
    key_columns = None

  # Add prediction dataset with key.
  if joining_data.prediction_data.HasField('gcs_source'):
    dataset = read_from_gcs(joining_data.prediction_data.gcs_source)
  else:
    dataset = read_from_bigquery(
        joining_data.prediction_data.bigquery_source.uri)
  dataset_with_key = (dataset
                      | 'FindKeyForInputData' >> beam.ParDo(
                          joiner_lib.FindKeyForJsonLData(
                              key_prefix=key_prefix_in_prediction_dataset,
                              key_columns=key_columns)).with_outputs(
                                  'errors', main='main')).main

  # Add ground truth dataset with key.
  if joining_data.ground_truth_data.HasField('gcs_source'):
    ground_truth_input_files = (joining_data.ground_truth_data.gcs_source.files)
    ground_truth_data_format = joining_data.ground_truth_data.gcs_source.format
    logging.info('Find ground truth input: %s, applying the merge step',
                 ground_truth_input_files)
    if ground_truth_data_format == configuration_pb2.DataSource.GcsSource.Format.CSV:
      ground_truth_dataset = csv_lib.read_csv_files_as_jsonl(
          pipeline, list(ground_truth_input_files))
    elif ground_truth_data_format == configuration_pb2.DataSource.GcsSource.Format.JSONL:
      ground_truth_dataset = (
          pipeline
          | 'InputGroundTruthFileList' >> beam.Create(ground_truth_input_files)
          | 'ReadGroundTruthText' >> beam.io.textio.ReadAllFromText())
    else:
      raise UserError(
          'Unsupported ground truth format %s, only allow CSV or JsonL' %
          (ground_truth_data_format))
  else:
    ground_truth_dataset = read_from_bigquery(
        joining_data.ground_truth_data.bigquery_source.uri, 'ground_truth')
  ground_truth_dataset_with_key = (
      ground_truth_dataset
      | 'FindKeyForGroundTruthData' >> beam.ParDo(
          joiner_lib.FindKeyForJsonLData(
              key_prefix='', key_columns=key_columns)).with_outputs(
                  'errors', main='main')).main

  return (
      (dataset_with_key, ground_truth_dataset_with_key)
      | 'GroupInputAndGroundTruth' >> beam.CoGroupByKey()
      | 'MergeInputAndGroundTruth' >> beam.ParDo(
          joiner_lib.MergePredictionWithGroundTruth(
              key_prefix_in_prediction_dataset=key_prefix_in_prediction_dataset,
              key_columns=key_columns)).with_outputs('errors', main='main')
  ).main
