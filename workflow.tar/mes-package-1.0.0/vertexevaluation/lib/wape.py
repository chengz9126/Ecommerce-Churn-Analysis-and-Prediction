"""Weighted absolute percentage error (WAPE) metric."""

import tensorflow as tf


class WeightedAbsolutePercentageError(tf.keras.metrics.Metric):
  """Custom keras metric class implemented WAPE.

  WAPE = sum(abs(y_true - y_pred)) / sum(abs(y_true))
  """

  def __init__(self, name='wape', **kwargs):
    super(WeightedAbsolutePercentageError, self).__init__(name=name, **kwargs)
    self.diff_sum = self.add_weight(name='wape_sum_diff', initializer='zeros')
    self.true_sum = self.add_weight(name='wape_sum_true', initializer='zeros')

  def update_state(self, y_true, y_pred, sample_weight=None):
    y_pred = tf.convert_to_tensor(y_pred, dtype=self.dtype)
    y_true = tf.cast(y_true, y_pred.dtype)
    if sample_weight is not None:
      sample_weight = tf.cast(sample_weight, self.dtype)
      y_pred = tf.multiply(sample_weight, y_pred)
      y_true = tf.multiply(sample_weight, y_true)

    self.diff_sum.assign_add(tf.reduce_sum(tf.math.abs(y_true - y_pred)))
    self.true_sum.assign_add(tf.reduce_sum(y_true))

  def result(self):
    return self.diff_sum / tf.math.maximum(self.true_sum,
                                           tf.keras.backend.epsilon())
