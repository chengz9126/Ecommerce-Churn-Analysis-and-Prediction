"""Process CSV files library access."""

import csv
import functools
import io
import json
from typing import Any, Iterable, List

from absl import logging
import apache_beam as beam
from apache_beam.io import iobase
from apache_beam.io.filebasedsource import FileBasedSource
from apache_beam.io.filebasedsource import ReadAllFiles
from apache_beam.io.filesystem import CompressionTypes
from apache_beam.io.filesystems import FileSystems
from apache_beam.transforms.ptransform import PTransform
import pandas as pd
import tensorflow as tf

_CSV_READER_CHUNK_SIZE = 3000


def _open_file(filename: str):
  """Chooses open file method according to its path prefix."""
  return io.TextIOWrapper(
      FileSystems.open(filename, mime_type='application/octet-stream'),
      line_buffering=True)


def get_header_from_csv(filenames: List[str]) -> Iterable[str]:
  """Gets a list of column names (header) from csv files."""
  print('type of filenames: {}'.format(type(filenames)))
  if not filenames:
    logging.error('Empty list of CSV files to fetch header')
    return []
  filename = sorted(filenames)[0]
  logging.info('Read header from CSV %s among %s', filename, filenames)
  try:
    with _open_file(filename) as csv_file:
      reader = csv.reader(csv_file)
      header = next(reader, None)
      if header is None:
        # TODO(b/238033735) Throw a user error.
        raise ValueError('No header is found in CSV file: {}'.format(filename))
      return header
  except (UnicodeDecodeError, FileNotFoundError, ValueError) as e:
    # TODO(b/238033735) Throw a user error.
    raise ValueError('Invalid CSV file {}.'.format(filename)) from e
  except Exception as e:  # pylint: disable=broad-except
    # TODO(b/238033735) Throw a user error.
    raise ValueError(
        'Failed to get header from csv {}.'.format(filename)) from e


class _CsvSource(FileBasedSource):
  """CSV file source for single CSV file, resulting list-like rows.

  CSV data is read and converted to string type.

  If the head line of the rest CSV file(s) is the same as
  header, reader will skip the first line(s). If the head line of the rest CSV
  differs to header, reader will read this head line as valid row data.

  If the target CSV file doesn't exist, the ValueError will be raised by
  corresponding open method.

  """

  def __init__(self, file_pattern: str, header: List[str]):
    try:
      super(_CsvSource, self).__init__(
          file_pattern=file_pattern, splittable=False)
    except IOError as e:
      # TODO(b/238033735) Throw a user error.
      raise ValueError('Invalid CSV file {}.'.format(file_pattern)) from e
    self._header = header

  def read_records(self, file_name: str,
                   offset_range_tracker: iobase.RangeTracker):
    """Parses list-like rows like from the given CSV file."""
    if offset_range_tracker.start_position():
      # TODO(b/238033735) Throw an internal error.
      raise ValueError('Start position not 0: {}.'.format(
          offset_range_tracker.start_position()))
    if not offset_range_tracker.try_claim(0):
      # TODO(b/238033735) Throw an internal error.
      raise ValueError('Unable to claim position: 0')

    try:
      done_header = False
      chunks = pd.read_csv(
          file_name,
          chunksize=_CSV_READER_CHUNK_SIZE,
          header=None,
          dtype=str,
          na_filter=False)
      for chunk in chunks:
        for tup in chunk.itertuples():
          # remove the index column.
          row = list(tup)[1:]
          if not done_header:
            done_header = True
            if row == self._header:
              continue

          yield row
    except (UnicodeDecodeError, FileNotFoundError, ValueError) as e:
      # TODO(b/238033735) Throw a user error.
      raise ValueError('Invalid CSV file {}.'.format(file_name)) from e


class ReadFromCsvFiles(PTransform):
  """Reads list-like rows from all provided CSV files."""

  def __init__(self, csv_files: List[str], header: Iterable[str]):
    self._csv_files = csv_files
    self._header = header

  def expand(self, pcoll: beam.PCollection):
    source_from_file = functools.partial(_CsvSource, header=self._header)
    return (pcoll | beam.Create(self._csv_files)
            | 'ReadAllCsvFiles' >> ReadAllFiles(
                splittable=False,
                desired_bundle_size=0,
                min_bundle_size=0,
                compression_type=CompressionTypes.AUTO,
                source_from_file=source_from_file))


class ExtractJsonFromCsvRowDoFn(beam.DoFn):
  """Extracts training requests from the CSV training datasets."""

  def __init__(self, header):
    self._header = header

  def process(self, row: List[Any]) -> Iterable[str]:
    """Convertes a input of list-like CSV line to json string.

    Args:
      row: A list-like CSV row.

    Yields:
      A json object containing key-value pairs of csv columns.
    """

    if len(row) != len(self._header):
      yield beam.pvalue.TaggedOutput('errors', (
          f'raw length {len(row)} different from header length {len(self._header)}',
          row))
      return
    json_obj = {}
    for cell_idx in range(len(row)):
      json_obj[self._header[cell_idx]] = row[cell_idx]
    yield json.dumps(json_obj)


def read_csv_files_as_jsonl(pipeline: beam.Pipeline,
                            input_files: List[str]) -> beam.Pipeline:
  """Reads csv files and format it to JsonL.

  Args:
    pipeline: A beam pipeline.
    input_files: A list of csv files to read from.

  Returns:
    The beam pipeline.
  """
  file_names = []
  for file_pattern in input_files:
    file_names.extend(tf.io.gfile.glob(file_pattern))
  logging.info('Found csv files %s', file_names)
  header = get_header_from_csv(file_names)
  logging.info('CSV input header : %s', str(header))
  # TODO(b/238033735) Dump the errors into file for debugging purposes.
  return (pipeline
          | 'InputCSVFiles' >> ReadFromCsvFiles(file_names, header)
          | 'Reshuffle to Prevent Fusion' >> beam.Reshuffle()
          | 'ConvertToJsonL' >> beam.ParDo(ExtractJsonFromCsvRowDoFn(
              header)).with_outputs('errors', main='main')).main
