"""Backend main for feature attribution aggregation component.

Runs a beam pipeline calculating global feature importance from batch
prediction outputs.
"""

from typing import Sequence

import apache_beam
from vertexevaluation.lib import artifact_util
from vertexevaluation.lib import pipeline_arg_parser
from vertexevaluation.lib.beam import read_and_merge_data
from vertexevaluation.lib.config import get_pipeline_options_from_service_config
from vertexevaluation.lib.explanation_lib import aggregate_feature_attribution
from vertexevaluation.lib.pipeline_options import ExplanationOptions
from vertexevaluation.lib.pipeline_options import KfpOptions


def main(argv: Sequence[str]) -> None:
  argv = list(argv)
  explanation_opts = ExplanationOptions(argv)
  execution_spec = pipeline_arg_parser.build_execution_spec(argv)

  pipeline = apache_beam.Pipeline(
      options=get_pipeline_options_from_service_config(
          task_run_name='explanation', task_execution_spec=execution_spec))

  merged_dataset = read_and_merge_data(
      pipeline=pipeline,
      input_source_spec=pipeline_arg_parser.build_data_source(argv))
  _ = aggregate_feature_attribution(merged_dataset,
                                    explanation_opts.gcs_output_path)

  # Early cancellation
  artifact_util.run_with_cancellation_propagation(
      execution_spec=execution_spec,
      result=pipeline.run(),
      kfp_pipeline_opts=KfpOptions(argv))
