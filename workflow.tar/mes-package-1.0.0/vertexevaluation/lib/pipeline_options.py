"""Definition for the Model Eval Service pipeline options."""

import json

from apache_beam.options.pipeline_options import PipelineOptions
from vertexevaluation.lib import constants


class ModelEvaluationServiceOptions(PipelineOptions):
  """Options supplied by model evaluation service."""

  @classmethod
  def _add_argparse_args(cls, parser):
    parser.add_argument(
        '--config',
        type=json.loads,
        help=(
            'Configuration for the model evaluation container represented as a '
            'serialized JSON string. The configuration message is defined in '
            'vertexevaluation/proto/configuration.proto.'))
    parser.add_argument(
        '--config_gcs_uri',
        type=str,
        default='',
        help=('GCS URI of the GCS object that contains the content of'
              'configuration for the model evaluation backend represented as a '
              'serialized JSON string. The configuration message is defined in '
              'vertexevaluation/proto/configuration.proto.'))
    parser.add_argument(
        '--project_id',
        type=str,
        default='',
        help='The ID of the Vertex project that the job belongs to.')
    parser.add_argument(
        '--location',
        type=str,
        default='us-central1',
        help='The regional endpoint for which to direct the request.')
    parser.add_argument(
        '--display_name',
        type=str,
        default='evaluation-run',
        help='The display name for this evaluation run.')
    parser.add_argument(
        '--problem_type',
        type=str,
        default='',
        help=('Specification for the evaluation run. Currently can be '
              '"classification" or "regression"'))
    parser.add_argument(
        '--batch_prediction_format',
        type=str,
        default='jsonl',
        help=('The file format for the batch prediction results. "jsonl" and '
              '"bigquery" are allowed formats currently.'))
    parser.add_argument(
        '--batch_prediction_gcs_source',
        type=str,
        default='',
        help=('The GCS directory where batch prediction results are located. '
              'Comes from the google.VertexBatchPredictionJob'))
    parser.add_argument(
        '--batch_prediction_bigquery_source',
        type=str,
        default='',
        help=('The BigQuery table where batch prediction results are located. '
              'Comes from the google.VertexBatchPredictionJob'))
    parser.add_argument(
        '--ground_truth_format',
        type=str,
        default='jsonl',
        help=('The file format for the ground truth data. "jsonl", "csv" and '
              '"bigquery" are allowed formats currently.'))
    parser.add_argument(
        '--ground_truth_gcs_source',
        type=json.loads,
        default={},
        help='The GCS directory where ground truth data are located.')
    parser.add_argument(
        '--ground_truth_bigquery_source',
        type=str,
        default='',
        help='The BigQuery table where ground truth data are located.')
    parser.add_argument(
        '--output_metrics_gcs_path',
        type=str,
        default='',
        help='The GCS path where evaluation metrics will save to.')
    parser.add_argument(
        '--output_explanation_gcs_path',
        type=str,
        default='',
        help='The GCS path where explanation metrics will save to.')
    parser.add_argument(
        '--root_dir',
        type=str,
        default='',
        help='The GCS directory for keeping staging files.')
    parser.add_argument(
        '--generate_feature_attribution',
        type=_my_boolean_parser,
        default=False,
        help='If true, generate feature attributions.')
    parser.add_argument(
        '--model_name',
        type=str,
        default='',
        help='The Vertex AI model resource name.')


class KfpOptions(PipelineOptions):
  """Options supplied by Kubeflow Pipelines."""

  @classmethod
  def _add_argparse_args(cls, parser):
    parser.add_argument(
        '--executor_input',
        type=str,
        default='',
        help='The KFP execution input for attaching output parameters.')
    parser.add_argument(
        '--gcp_resources',
        type=str,
        default='',
        help='The metadata of resources.')


class ModelEvaluationServiceTabularOptions(PipelineOptions):
  """Tabular problem type options supplied by model evaluation service."""

  @classmethod
  def _add_argparse_args(cls, parser):
    parser.add_argument(
        '--classification_type',
        type=str,
        default='multiclass',
        help='Type of classification problem: "multiclass" or "multilabel".')
    parser.add_argument(
        '--class_labels',
        dest='class_names',
        type=json.loads,
        default={},
        help=('The list of class names, in the same order they appear in batch '
              'predictions column.'))
    parser.add_argument(
        '--target_field_name',
        type=str,
        default='',
        help=('The column name of the feature containing ground truth in '
              'tabular data. In unstructured data, the target '
              'label/classification.'))
    parser.add_argument(
        '--prediction_score_column',
        type=str,
        default='',
        help='The column name for the field containing model scores.')
    parser.add_argument(
        '--prediction_label_column',
        type=str,
        default='',
        help=('Optional. The column name for the field containing classes the '
              'model is scoring.'))
    parser.add_argument(
        '--prediction_id_column',
        type=str,
        default='',
        help=('Optional. The column name for the field containing ids for '
              'classes the model is scoring.'))
    parser.add_argument(
        '--example_weight_column',
        type=str,
        default='',
        help=('Optional. The column name for the field containing example '
              'weights.'))
    parser.add_argument(
        '--top_k_list',
        type=json.loads,
        help=('Optional. Creates binary classification metrics based on the '
              'top k predicted values for each value of top_k_list provided.'))
    parser.add_argument(
        '--positive_classes',
        type=json.loads,
        help=('Optional. Creates binary classification metrics based on '
              'one-vs-rest for each value of positive_class provided.'))
    parser.add_argument(
        '--decision_thresholds',
        default=constants.Thresholds.THRESHOLD_LIST,
        nargs='+',
        help=('Optional decision thresholds. Default: THRESHOLD_LIST in '
              'constants. If the top prediction is less than a threshold then '
              'the associated example will be assumed to have no prediction '
              'associated with it. This will be applied to '
              'MutliClassConfusionMatrix.'))
    parser.add_argument(
        '--forecasting_type',
        type=str,
        default='point',
        help=('Optional. Either point or quantile forecasting type'))
    parser.add_argument(
        '--forecasting_quantiles',
        type=json.loads,
        default=[0.5],
        help=(
            'The list of quantiles in the same order they appear in quantile prediction score column. Required if type is QUANTILE.'
        ))
    parser.add_argument(
        '--point_evaluation_quantile_index',
        type=int,
        help=(
            'Optional. Only applicable if forecasting type is QUANTILE. Specify to generate point accuracy metrics for the point at the specified index in the quartiles list'
        ))
    parser.add_argument(
        '--compute_fairness',
        type=_my_boolean_parser,
        default=False,
        help=('Optional. If true, compute fairness metrics.'))
    parser.add_argument(
        '--fairness_slices',
        type=str,
        default=[],
        nargs='+',
        action='append',
        help=(
            'Optional fairness slices. Only applicable if compute fairness is True.'
            'The list of names of columns that are used for slicing for fairness metrics. '
        ))
    parser.add_argument(
        '--fairness_thresholds',
        default=[0.1, 0.3, 0.5, 0.7, 0.9],
        nargs='+',
        help=(
            'Optional fairness thresholds. Only applicable if compute fairness is True. '
            'Default: 0.1, 0.3, 0.5, 0.7, 0.9 . '
            'Evaluates fairness performance at the threshold values.'))
    # TODO(b/241974241): Complete options in model_evaluation.proto.
    parser.add_argument(
        '--compute_confidence_intervals',
        type=_my_boolean_parser,
        default=False,
        help=('Optional. Only applicable if compute fairness is True. '
              'If true, compute confidence intervals.'))


class ModelEvaluationServiceDataflowOptions(PipelineOptions):
  """Dataflow options supplied by model evaluation service."""

  @classmethod
  def _add_argparse_args(cls, parser):
    parser.add_argument(
        '--dataflow_job_prefix',
        type=str,
        default='evaluation-dataflow',
        help='The prefix of the dataflow job.')
    parser.add_argument(
        '--dataflow_service_account',
        type=str,
        default='',
        help='Optional. The service account running the dataflow job.')
    parser.add_argument(
        '--dataflow_disk_size',
        type=int,
        default=200,
        help=('Optional. The disk size (in GB) of the machine running the '
              'dataflow job.'))
    parser.add_argument(
        '--dataflow_machine_type',
        type=str,
        default='n1-standard-4',
        help='Optional. The machine type running the dataflow job.')
    parser.add_argument(
        '--dataflow_workers_num',
        type=int,
        default=1,
        help='Optional. The number of workers running the dataflow job.')
    parser.add_argument(
        '--dataflow_max_workers_num',
        type=int,
        default=5,
        help='Optional. The max number of workers running the dataflow job.')
    parser.add_argument(
        '--kms_key_name',
        type=str,
        default='',
        help=(
            'Optional. Customer-managed encryption key options for the '
            'dataflow job. If this is set, then all resources created by the '
            'dataflow job will be encrypted with the provided encryption key. '
            'Has the format: `projects/my-project/locations/my-location/keyRings/my-kr/cryptoKeys/my-key`.'
            'Needs to be in the same region where the compute resource is '
            'created.'))
    parser.add_argument(
        '--dataflow_subnetwork',
        type=str,
        default='',
        help=('Optional. GCE subnetwork for launching workers. Default is up '
              'to the Dataflow service. Expected format is '
              'regions/REGION/subnetworks/SUBNETWORK or the fully qualified '
              'subnetwork name. For more information, see '
              'https://cloud.google.com/compute/docs/vpc/'))
    parser.add_argument(
        '--dataflow_worker_container_image',
        type=str,
        default='',
        help='Optional. The container for the dataflow workers to run on.')
    parser.add_argument(
        '--dataflow_use_public_ips',
        type=_my_boolean_parser,
        default=True,
        help='If true, assign public IP addresses to the worker VMs.')


def _my_boolean_parser(argument):
  """Support both --flag and --flag=<bool_value>."""
  bool_arg = True
  if argument.lower() == 'false' or argument == '0':
    bool_arg = False
  return bool_arg


class DevelModelEvaluationServiceOptions(PipelineOptions):
  """Developer options."""

  @classmethod
  def _add_argparse_args(cls, parser):
    parser.add_argument(
        '--json_mode',
        type=_my_boolean_parser,
        default=False,
        help=('If true, output as JSON parseable format instead of TFRecord.'))
    parser.add_argument(
        '--tfma_format',
        type=_my_boolean_parser,
        default=False,
        help=('If true, output TFMA-compatible metrics instead of MES.'))


class TaskOptions(PipelineOptions):
  """Task options supplied by task type to run in this container."""

  @classmethod
  def _add_argparse_args(cls, parser):
    parser.add_argument(
        '--task',
        type=str,
        default='evaluation',
        help=('Start pipeline for the designated task, the supported tasks are '
              'evaluation/data_sampler/data_splitter/explanation. '
              'If not provided, default to evaluation'))


class PreprocessingServiceOptions(PipelineOptions):
  """Options supplied by preprocessing component service."""

  @classmethod
  def _add_argparse_args(cls, parser):
    parser.add_argument(
        '--gcs_source_uris',
        type=json.loads,
        default=[],
        help=(
            'Google Cloud Storage URI(-s) to your instances to run '
            'preprocessing components on. They must match `instances_format`. May contain '
            'wildcards.'))

    parser.add_argument(
        '--bigquery_source_uri',
        type=str,
        default='',
        help=('Google BigQuery URI to your instances to run '
              'preprocessing components on.'))

    parser.add_argument(
        '--instances_format',
        type=str,
        default='jsonl',
        help=(
            'Optional. Default: jsonl. The format in which input instances are '
            'given, must be one of the models supported input storage formats.'
        ))

    parser.add_argument(
        '--gcs_directory_for_gcs_output_uris',
        type=str,
        default='',
        help=('The KFP pipeline file GCS path where preprocessing output '
              'dataset path will save to.'))

    parser.add_argument(
        '--bigquery_output_uri',
        type=str,
        default='',
        help=('Google BigQuery table URI where preprocessing output '
              'dataset will save to. Required when using BigQuery source.'))

    parser.add_argument(
        '--gcs_directory_for_bigquery_output_table_uri',
        type=str,
        default='',
        help=('The KFP pipeline file GCS path where preprocessing output '
              'BigQuery table URI will save to.'))

    parser.add_argument(
        '--sample_size',
        type=int,
        default=10000,
        help=('Optional. Default: 10000. Sample size of the randomly sampled '
              'dataset for the data sampler component.'))


class ExplanationOptions(PipelineOptions):
  """Options for generating explanations (feautre attributions)."""

  @classmethod
  def _add_argparse_args(cls, parser):
    parser.add_argument(
        '--gcs_output_path',
        type=str,
        default='',
        help='The GCS path where feature attributions will be saved to.')


class SlicingOptions(PipelineOptions):
  """Options for generating sliced metrics."""

  @classmethod
  def _add_argparse_args(cls, parser):
    parser.add_argument(
        '--slice_columns',
        type=str,
        nargs='*',
        help='Designates the column that should be used to generate the slices.',
        action='append')
    parser.add_argument(
        '--slice_features',
        type=str,
        nargs='*',
        help='Will feed into the features proto and designate the feature name.',
        action='append')
    parser.add_argument(
        '--feature_values',
        type=str,
        nargs='*',
        help='Will feed into the features proto and set the value for the feature.',
        action='append')
