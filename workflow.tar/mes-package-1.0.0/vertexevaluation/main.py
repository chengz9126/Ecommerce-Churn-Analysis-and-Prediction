"""A main that wraps the underlying main for evaluation backend."""

import sys

from vertexevaluation.error import error
from vertexevaluation.lib import eval_backend_main
from vertexevaluation.lib import explanation_main
from vertexevaluation.lib import pipeline_options
from vertexevaluation.lib import preprocessing

UserError = error.UserError
ErrorHandler = error.ErrorHandler

# Import after applying the module aliases.
_USAGE = """
  main.py --task=<evaluation|data_splitter|data_sampler|explanation> [--config=<serialized_json>] [KFP pipeline args]
"""

if __name__ == '__main__':
  print('Running main with (%r)' % sys.argv)

  task = pipeline_options.TaskOptions(sys.argv).task
  if task not in ['evaluation', 'data_splitter', 'data_sampler', 'explanation']:
    raise UserError('USAGE: \n {}'.format(_USAGE))

  root_dir = pipeline_options.ModelEvaluationServiceOptions(sys.argv).root_dir
  with ErrorHandler(root_dir):
    if task == 'evaluation':
      eval_backend_main.evaluation_run(sys.argv)
    elif task == 'data_splitter':
      preprocessing.data_splitter_run(sys.argv)
    elif task == 'data_sampler':
      preprocessing.data_sampler_run(sys.argv)
    elif task == 'explanation':
      explanation_main.main(sys.argv)
