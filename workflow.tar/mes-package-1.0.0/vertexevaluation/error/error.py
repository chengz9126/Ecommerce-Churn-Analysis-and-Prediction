"""Error classes and utilites."""

import os
import sys
import traceback

from absl import logging
import tensorflow.compat.v1 as tf
from vertexevaluation.lib import constants


class UserError(Exception):
  """UserError class for exceptions that are caused by user input."""
  pass


class ErrorHandler:
  """A class-based context manager for error handling."""

  def __init__(self, root_dir: str):
    """Fetches the pipeline output error file uri.

    If the pipeline output error file already exists, program exits to avoid
    retrying multiple times.

    Args:
      root_dir: The root_dir uri.
    """
    self.error_file_uri = os.path.join(
        os.path.join(root_dir, constants.Pipeline.ERROR_FOLDER_NAME),
        constants.Pipeline.ERROR_FILE_NAME)
    logging.info('ErrorHandler: Output error file uri: %s', self.error_file_uri)

    if tf.io.gfile.exists(self.error_file_uri):
      logging.error('ErrorHandler: error file exists at %s, abort',
                    self.error_file_uri)
      with tf.io.gfile.GFile(self.error_file_uri, 'r') as error_file:
        logging.error('Error file contents :')
        for line in error_file:
          logging.error(line)
      sys.exit(-1)

  def __enter__(self):
    pass

  def __exit__(self, exc_type, exc_value, exc_tb):

    if not exc_type:
      # No exceptions raised.
      return

    # Log Error in detail, including traceback.
    with tf.io.gfile.GFile(self.error_file_uri, 'w') as f:
      f.write('Error Type : {}\n'.format(exc_type.__name__))
      f.write('Error Message : {}\n'.format(exc_value))
      for line in traceback.format_tb(exc_tb):
        f.write(line + '\n')

    # Report Internal Errors to SLO.
    if exc_type != UserError:
      logging.error('Error Type : %s', exc_type.__name__)
      logging.error('Error Message : %s', exc_value)
      for line in traceback.format_tb(exc_tb):
        logging.error(line)
      sys.exit(constants.VERTEX_PIPELINE_COMPONENT_FAILURE_CODE)
