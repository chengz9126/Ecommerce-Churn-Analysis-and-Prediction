"""Setup for DataFlow Worker environments."""
import setuptools

setuptools.setup(
    name='mes-package',
    version='1.0.0',
    description='Vertex AI Evaluation package.',
    packages=setuptools.find_packages(),
)
